import pandas as pd
import numpy as np
import xgboost as xgb
import matplotlib.pyplot as plt
import os
import requests
import glob
from datetime import timedelta, date
from sklearn.metrics import mean_squared_error

def get_month_url(year, month, region="SA1"):
    ym = f"{year}{month:02d}"
    return f"https://aemo.com.au/aemo/data/nem/priceanddemand/PRICE_AND_DEMAND_{ym}_{region}.csv"

def download_month_data(year, month, region="SA1", save_folder=r"D:\Python 脚本\aemo_data"):
    url = get_month_url(year, month, region)
    filename = url.split("/")[-1]
    save_path = os.path.join(save_folder, filename)
    headers = {"User-Agent": "Mozilla/5.0"}
    os.makedirs(save_folder, exist_ok=True)
    if os.path.exists(save_path):
        print(f"📁 File already exists: {save_path}")
        return save_path
    print(f"🌐 Starting download: {url}")
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        with open(save_path, "wb") as f:
            f.write(response.content)
        print(f"✅ Download successful: {save_path}")
        return save_path
    else:
        print(f"❌ Download failed: {url}")
        return None

def clear_data_folder(folder_path):
    csv_files = glob.glob(os.path.join(folder_path, "*.csv"))
    for f in csv_files:
        try:
            os.remove(f)
            print(f"🗑️ Deleted old file: {f}")
        except Exception as e:
            print(f"⚠️ Failed to delete {f}, reason: {e}")

def prepare_data():
    data_folder = r"D:\Python 脚本\aemo_data"
    clear_data_folder(data_folder)
    today = date.today()
    current_year, current_month = today.year, today.month
    last_month = 12 if current_month == 1 else current_month - 1
    last_year = current_year - 1 if current_month == 1 else current_year

    current_file = download_month_data(current_year, current_month, save_folder=data_folder)
    df_current = pd.read_csv(current_file)
    df_current = df_current[['SETTLEMENTDATE', 'TOTALDEMAND', 'RRP']]
    df_current['SETTLEMENTDATE'] = pd.to_datetime(df_current['SETTLEMENTDATE'])

    latest_time = df_current['SETTLEMENTDATE'].max()
    earliest_time = df_current['SETTLEMENTDATE'].min()

    # ✅ Corrected logic for checking data length
    if (latest_time - earliest_time) < timedelta(days=7):
        print("⚠️ Current month data is less than 7 days. Trying to supplement with last month data...")
        last_file = download_month_data(last_year, last_month, save_folder=data_folder)
        df_last = pd.read_csv(last_file)
        df_last = df_last[['SETTLEMENTDATE', 'TOTALDEMAND', 'RRP']]
        df_last['SETTLEMENTDATE'] = pd.to_datetime(df_last['SETTLEMENTDATE'])
        df = pd.concat([df_last, df_current])
    else:
        df = df_current

    df.set_index('SETTLEMENTDATE', inplace=True)
    df = df.resample('1H').mean(numeric_only=True)
    df['DayOfWeek'] = df.index.dayofweek
    df['HourOfDay'] = df.index.hour
    df['IsWeekend'] = df['DayOfWeek'].apply(lambda x: 1 if x >= 5 else 0)
    df['Lag24'] = df['TOTALDEMAND'].shift(24)
    return df

def forecast(df):
    latest_time = df.index.max()
    train_start = latest_time - timedelta(days=7)
    train_end = latest_time
    train_data = df[train_start:train_end].dropna()
    if len(train_data) < 7 * 24:
        raise ValueError("❌ Not enough data (7 days) for forecasting.")
    X_train = train_data[['RRP', 'DayOfWeek', 'HourOfDay', 'IsWeekend', 'Lag24']]
    y_train = train_data['TOTALDEMAND']
    predict_start = latest_time + timedelta(hours=1)
    predict_end = predict_start + timedelta(hours=23)
    day_before = predict_start - timedelta(days=1)
    X_predict = df.loc[day_before:day_before + timedelta(hours=23)][['RRP', 'TOTALDEMAND']].copy()
    X_predict.rename(columns={'TOTALDEMAND': 'Lag24'}, inplace=True)
    X_predict['DayOfWeek'] = [predict_start.dayofweek] * 24
    X_predict['HourOfDay'] = list(range(24))
    X_predict['IsWeekend'] = [1 if predict_start.dayofweek >= 5 else 0] * 24
    if len(X_predict) < 24:
        raise ValueError("❌ Failed to retrieve 24 hours of data for prediction.")
    model = xgb.XGBRegressor(random_state=42)
    model.fit(X_train, y_train)
    y_train_pred = model.predict(X_train)
    rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
    print(f"📉 Training RMSE: {rmse:.2f}")
    y_pred = model.predict(X_predict[['RRP', 'DayOfWeek', 'HourOfDay', 'IsWeekend', 'Lag24']])
    predict_df = pd.DataFrame({
        'Time': pd.date_range(start=predict_start, end=predict_end, freq='H'),
        'Predicted_TOTALDEMAND': y_pred
    })
    output_folder = r"D:\Python 脚本\predict_data"
    os.makedirs(output_folder, exist_ok=True)
    output_path = os.path.join(output_folder, f"prediction_{predict_start.date()}.csv")
    predict_df.to_csv(output_path, index=False)
    print(f"✅ Forecast complete. Results saved to: {output_path}")
    return predict_df

def evaluate_rmse(df, window_days_list=[7, 14, 30]):
    results = []
    latest_time = df.index.max()
    predict_start = latest_time + timedelta(hours=1)
    day_before = predict_start - timedelta(days=1)
    X_predict = df.loc[day_before:day_before + timedelta(hours=23)][['RRP', 'TOTALDEMAND']].copy()
    X_predict.rename(columns={'TOTALDEMAND': 'Lag24'}, inplace=True)
    X_predict['DayOfWeek'] = [predict_start.dayofweek] * 24
    X_predict['HourOfDay'] = list(range(24))
    X_predict['IsWeekend'] = [1 if predict_start.dayofweek >= 5 else 0] * 24
    if len(X_predict) < 24:
        raise ValueError("❌ Failed to retrieve 24 hours of data for prediction.")
    for days in window_days_list:
        train_start = latest_time - timedelta(days=days)
        train_end = latest_time
        train_data = df[train_start:train_end].dropna()
        if len(train_data) < days * 24:
            print(f"⚠️ Skipping {days}-day window due to insufficient data.")
            continue
        X_train = train_data[['RRP', 'DayOfWeek', 'HourOfDay', 'IsWeekend', 'Lag24']]
        y_train = train_data['TOTALDEMAND']
        model = xgb.XGBRegressor(random_state=42)
        model.fit(X_train, y_train)
        y_pred_train = model.predict(X_train)
        train_rmse = np.sqrt(mean_squared_error(y_train, y_pred_train))
        results.append((days, train_rmse))
        print(f"✅ Window {days} days → Training RMSE: {train_rmse:.4f}")
    if results:
        windows, rmses = zip(*results)
        plt.figure(figsize=(8, 5))
        plt.plot(windows, rmses, marker='o')
        plt.title("RMSE Comparison Across Different Training Windows (with Lag24)")
        plt.xlabel("Training Days")
        plt.ylabel("Training RMSE")
        plt.grid(True)
        plt.show()
    else:
        print("⚠️ No results available to plot. Possibly due to lack of valid data.")

if __name__ == "__main__":
    df = prepare_data()
    evaluate_rmse(df)
    forecast(df)
