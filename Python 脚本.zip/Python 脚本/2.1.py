import pandas as pd
import numpy as np
import xgboost as xgb
import matplotlib.pyplot as plt
import os
import requests
import datetime
import glob
from datetime import timedelta, date

# ========== 1. 构造月份URL函数 ========== #
def get_month_url(year, month, region="SA1"):
    ym = f"{year}{month:02d}"
    return f"https://aemo.com.au/aemo/data/nem/priceanddemand/PRICE_AND_DEMAND_{ym}_{region}.csv"

# ========== 2. 下载指定年月数据 ========== #
def download_month_data(year, month, region="SA1", save_folder=r"D:\Python 脚本\aemo_data"):
    url = get_month_url(year, month, region)
    filename = url.split("/")[-1]
    save_path = os.path.join(save_folder, filename)
    
    headers = {"User-Agent": "Mozilla/5.0"}
    os.makedirs(save_folder, exist_ok=True)

    # 如果文件已存在就不重复下载
    if os.path.exists(save_path):
        print(f"📁 文件已存在：{save_path}")
        return save_path

    print(f"🌐 开始下载：{url}")
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        with open(save_path, "wb") as f:
            f.write(response.content)
        print(f"✅ 下载成功：{save_path}")
        return save_path
    else:
        print(f"❌ 下载失败：{url}")
        return None

# ========== 3. 清空文件夹 ========== #
def clear_data_folder(folder_path):
    csv_files = glob.glob(os.path.join(folder_path, "*.csv"))
    for f in csv_files:
        try:
            os.remove(f)
            print(f"🗑️ 已删除旧文件：{f}")
        except Exception as e:
            print(f"⚠️ 删除失败：{f}，原因：{e}")

# ========== 4. 下载数据并确保7天以上 ========== #
def prepare_data():
    data_folder = r"D:\Python 脚本\aemo_data"
    clear_data_folder(data_folder)

    today = date.today()
    current_year, current_month = today.year, today.month
    last_month = 12 if current_month == 1 else current_month - 1
    last_year = current_year - 1 if current_month == 1 else current_year

    # 下载当前月数据
    current_file = download_month_data(current_year, current_month, save_folder=data_folder)
    df_current = pd.read_csv(current_file)
    df_current = df_current[['SETTLEMENTDATE', 'TOTALDEMAND', 'RRP']]
    df_current['SETTLEMENTDATE'] = pd.to_datetime(df_current['SETTLEMENTDATE'])

    # 检查是否满7天数据
    latest_time = df_current['SETTLEMENTDATE'].max()
    if df_current['SETTLEMENTDATE'].min() > (latest_time - timedelta(days=7)):
        print("⚠️ 当前月数据不足7天，尝试补充上月数据...")
        last_file = download_month_data(last_year, last_month, save_folder=data_folder)
        df_last = pd.read_csv(last_file)
        df_last = df_last[['SETTLEMENTDATE', 'TOTALDEMAND', 'RRP']]
        df_last['SETTLEMENTDATE'] = pd.to_datetime(df_last['SETTLEMENTDATE'])
        df = pd.concat([df_last, df_current])
    else:
        df = df_current

    # 设置索引 & 小时均值 & 添加星期几特征
    df.set_index('SETTLEMENTDATE', inplace=True)
    df = df.resample('1H').mean(numeric_only=True)
    df['DayOfWeek'] = df.index.dayofweek  # 添加星期几（0=Monday, ..., 6=Sunday）
    return df

# ========== 5. 模型训练与预测 ========== #
def forecast(df):
    latest_time = df.index.max()
    train_start = latest_time - timedelta(days=7)
    train_end = latest_time
    train_data = df[train_start:train_end]

    if len(train_data) < 7 * 24:
        raise ValueError("❌ 数据不足7天，无法进行预测。")

    # 特征与标签
    X_train = train_data[['RRP', 'DayOfWeek']]
    y_train = train_data['TOTALDEMAND']

    # 构建预测输入数据（使用前一天的RRP和星期几）
    predict_start = latest_time + timedelta(hours=1)
    predict_end = predict_start + timedelta(hours=23)
    day_before = predict_start - timedelta(days=1)
    X_predict = df.loc[day_before:day_before + timedelta(hours=23)][['RRP']]
    X_predict['DayOfWeek'] = [predict_start.dayofweek] * 24  # 假设预测日整天都属于同一天

    if len(X_predict) < 24:
        raise ValueError("❌ 无法获取24小时RRP数据用于预测。")

    # 模型训练 & 预测
    model = xgb.XGBRegressor()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_predict)

    # 保存结果
    predict_df = pd.DataFrame({
        'Time': pd.date_range(start=predict_start, end=predict_end, freq='H'),
        'Predicted_TOTALDEMAND': y_pred
    })

    output_folder = r"D:\Python 脚本\predict_data"
    os.makedirs(output_folder, exist_ok=True)
    output_path = os.path.join(output_folder, f"prediction_{predict_start.date()}.csv")
    predict_df.to_csv(output_path, index=False)

    print(f"✅ 预测完成，结果保存为：{output_path}")
    return predict_df

# ========== 6. 主程序入口 ========== #
if __name__ == "__main__":
    df = prepare_data()
    forecast(df)
