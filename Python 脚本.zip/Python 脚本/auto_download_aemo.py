import requests
import datetime
import os
import glob

def get_current_month_url(region="SA1"):
    today = datetime.date.today()
    ym = f"{today.year}{today.month:02d}"
    return f"https://aemo.com.au/aemo/data/nem/priceanddemand/PRICE_AND_DEMAND_{ym}_{region}.csv"

def download_aemo(region="SA1", save_folder=r"D:\Python 脚本\aemo_data"):
    url = get_current_month_url(region)
    filename = url.split("/")[-1]

    # 创建保存目录
    os.makedirs(save_folder, exist_ok=True)

    # 清空目录中所有 .csv 文件
    old_files = glob.glob(os.path.join(save_folder, "*.csv"))
    for f in old_files:
        try:
            os.remove(f)
            print(f"🗑️ 已删除旧文件：{f}")
        except Exception as e:
            print(f"⚠️ 删除失败：{f}，原因：{e}")

    # 下载文件
    save_path = os.path.join(save_folder, filename)
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0 Safari/537.36"
    }

    print(f"🌐 开始下载：{url}")
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        with open(save_path, "wb") as f:
            f.write(response.content)
        print(f"✅ 下载成功，文件已保存至：{save_path}")
    else:
        print(f"❌ 下载失败，状态码：{response.status_code}")

# 执行
download_aemo("SA1")
