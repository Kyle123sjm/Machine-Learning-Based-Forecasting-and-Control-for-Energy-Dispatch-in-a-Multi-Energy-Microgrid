import pandas as pd
import numpy as np
import os
import glob
import requests
import xgboost as xgb
import matplotlib.pyplot as plt
from datetime import timedelta, date, datetime
from sklearn.metrics import mean_squared_error

# ========== 1. 获取并下载数据 ========== #
def get_month_url(year, month, region="SA1"):
    ym = f"{year}{month:02d}"
    return f"https://aemo.com.au/aemo/data/nem/priceanddemand/PRICE_AND_DEMAND_{ym}_{region}.csv"

def download_month_data(year, month, region="SA1", save_folder=r"D:\Python 脚本\aemo_data"):
    os.makedirs(save_folder, exist_ok=True)
    url = get_month_url(year, month, region)
    filename = url.split("/")[-1]
    save_path = os.path.join(save_folder, filename)

    if os.path.exists(save_path):
        print(f"✅ 已存在：{filename}")
        return save_path

    print(f"⬇️ 正在下载：{filename}")
    response = requests.get(url, headers={"User-Agent": "Mozilla/5.0"})
    if response.status_code == 200:
        with open(save_path, "wb") as f:
            f.write(response.content)
        print(f"✅ 下载成功：{filename}")
        return save_path
    else:
        print(f"❌ 下载失败：{filename}")
        return None

def download_data_range(start_year, start_month, end_year, end_month):
    for year in range(start_year, end_year + 1):
        for month in range(1, 13):
            if (year == start_year and month < start_month) or (year == end_year and month > end_month):
                continue
            download_month_data(year, month)

# ========== 2. 准备数据 ========== #
def prepare_data(data_folder):
    files = glob.glob(os.path.join(data_folder, "*.csv"))
    df_list = []
    for f in files:
        try:
            df = pd.read_csv(f)[['SETTLEMENTDATE', 'TOTALDEMAND', 'RRP']]
            df['SETTLEMENTDATE'] = pd.to_datetime(df['SETTLEMENTDATE'])
            df_list.append(df)
        except:
            print(f"⚠️ 跳过无效文件：{f}")
    df = pd.concat(df_list)
    df.set_index('SETTLEMENTDATE', inplace=True)
    df = df.sort_index()
    df = df.resample('1H').mean(numeric_only=True)
    df['DayOfWeek'] = df.index.dayofweek
    df['HourOfDay'] = df.index.hour
    df['IsWeekend'] = df['DayOfWeek'].apply(lambda x: 1 if x >= 5 else 0)
    df['Lag24'] = df['TOTALDEMAND'].shift(24)
    return df.dropna()

# ========== 3. 进行滚动预测 ========== #
def rolling_forecast(df, start_date, end_date, output_folder):
    os.makedirs(output_folder, exist_ok=True)
    rmse_list = []

    for single_date in pd.date_range(start=start_date, end=end_date):
        train_end = single_date - pd.Timedelta(hours=1)
        train_start = train_end - pd.Timedelta(days=7)
        train_data = df[train_start:train_end]

        if len(train_data) < 7 * 24:
            print(f"❌ {single_date.date()}：训练数据不足，跳过")
            continue

        X_train = train_data[['RRP', 'DayOfWeek', 'HourOfDay', 'IsWeekend', 'Lag24']]
        y_train = train_data['TOTALDEMAND']

        predict_start = single_date
        predict_end = single_date + pd.Timedelta(hours=23)
        predict_data = df[predict_start - pd.Timedelta(days=1): predict_start - pd.Timedelta(days=1) + pd.Timedelta(hours=23)][['RRP', 'TOTALDEMAND']].copy()
        if len(predict_data) < 24:
            print(f"⚠️ {single_date.date()}：预测输入不足24小时，跳过")
            continue

        predict_data.rename(columns={'TOTALDEMAND': 'Lag24'}, inplace=True)
        predict_data['DayOfWeek'] = [single_date.dayofweek] * 24
        predict_data['HourOfDay'] = list(range(24))
        predict_data['IsWeekend'] = [1 if single_date.dayofweek >= 5 else 0] * 24

        X_predict = predict_data[['RRP', 'DayOfWeek', 'HourOfDay', 'IsWeekend', 'Lag24']]
        y_true = df[predict_start:predict_end]['TOTALDEMAND'].values
        if len(y_true) < 24:
            print(f"⚠️ {single_date.date()}：真实值不足24小时，跳过")
            continue

        model = xgb.XGBRegressor(random_state=42)
        model.fit(X_train, y_train)
        y_pred = model.predict(X_predict)

        rmse = np.sqrt(mean_squared_error(y_true, y_pred))
        rmse_list.append((single_date.date(), rmse))

        # ✅ 可视化
        plt.figure(figsize=(10, 5))
        plt.plot(range(24), y_true, label="Actual", color='blue')
        plt.plot(range(24), y_pred, label="Predicted", color='orange')
        plt.title(f"Forecast vs Actual for {single_date.date()}")
        plt.xlabel("Hour")
        plt.ylabel("TOTALDEMAND")
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(output_folder, f"forecast_{single_date.date()}.png"))
        plt.close()

    # ✅ 画出RMSE曲线
    if rmse_list:
        dates, rmses = zip(*rmse_list)
        plt.figure(figsize=(10, 5))
        plt.plot(dates, rmses, marker='o', linestyle='-')
        plt.title("Daily Forecast RMSE (Next 24h)")
        plt.xlabel("Date")
        plt.ylabel("RMSE")
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(os.path.join(output_folder, "daily_rmse_curve.png"))
        plt.show()

# ========== 4. 主程序入口 ========== #
if __name__ == "__main__":
    data_folder = r"D:\Python 脚本\aemo_data"
    output_folder = r"D:\Python 脚本\predict_data"

    # 下载 2025 年 7月 和 8月数据
    download_data_range(2025, 7, 2025, 8)

    df = prepare_data(data_folder)

    # 设置滚动预测起止范围（例如 8月1日 ~ 8月7日）
    rolling_forecast(df, start_date=pd.Timestamp("2025-08-01"), end_date=pd.Timestamp("2025-08-07"), output_folder=output_folder)
