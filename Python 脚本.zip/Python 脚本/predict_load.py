import pandas as pd
import xgboost as xgb
from sklearn.model_selection import train_test_split
import joblib

# 构造一个简单的负载预测数据集
df = pd.DataFrame({
    'hour': [1, 2, 3, 4, 5, 6],
    'last_load': [100, 120, 130, 140, 160, 170],
    'load': [110, 125, 135, 150, 165, 180]
})

# 拆分输入与目标
X = df[['hour', 'last_load']]
y = df['load']

# 分成训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# 训练模型
model = xgb.XGBRegressor()
model.fit(X_train, y_train)

# 保存模型到文件
joblib.dump(model, 'load_model.pkl')

# 测试预测
y_pred = model.predict(X_test)
print("预测值为：", y_pred)
