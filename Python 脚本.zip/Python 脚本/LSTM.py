import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from importlib.machinery import SourceFileLoader

# ========== 加载 prepare_data ==========
xgb_module = SourceFileLoader("xgb_module", "D:/Python 脚本/2.3.1.py").load_module()
df_full = xgb_module.prepare_data().dropna()

# ========== 公共参数 ==========
features = ['RRP', 'DayOfWeek', 'HourOfDay', 'IsWeekend', 'Lag24']
target = 'TOTALDEMAND'
window_days_list = [7, 14, 30]
rmse_results = []

# ========== 构造序列函数 ==========
def create_sequences_multivar(data, input_features, target_col, input_len=24, output_len=24):
    X, y = [], []
    for i in range(len(data) - input_len - output_len):
        X.append(data[input_features].iloc[i:i + input_len].values)
        y.append(data[target_col].iloc[i + input_len:i + input_len + output_len].values)
    return np.array(X), np.array(y)

# ========== 多窗口训练循环 ==========
for days in window_days_list:
    print(f"\n🟡 Training with last {days} days")

    # 选取对应窗口的数据
    df = df_full[df_full.index >= df_full.index.max() - pd.Timedelta(days=days)]
    df = df[df.index <= df.index.max() - pd.Timedelta(hours=24)]  # 避免“偷看”预测日
    df = df.dropna()

    if len(df) < (24 + 24):
        print(f"❌ Not enough data for {days} days. Skipping.")
        continue

    # 标准化
    scaler_x = MinMaxScaler()
    scaler_y = MinMaxScaler()
    X_scaled = scaler_x.fit_transform(df[features])
    y_scaled = scaler_y.fit_transform(df[[target]])

    scaled_df = pd.DataFrame(X_scaled, columns=features, index=df.index)
    scaled_df['TOTALDEMAND'] = y_scaled

    # 构造样本
    X, y = create_sequences_multivar(scaled_df, features, 'TOTALDEMAND', input_len=24, output_len=24)
    X_train, y_train = X[:-1], y[:-1]
    X_test, y_test = X[-1:], y[-1:]

    # 模型构建
    model = Sequential()
    model.add(LSTM(64, input_shape=(X.shape[1], X.shape[2])))
    model.add(Dense(24))
    model.compile(optimizer='adam', loss='mse')

    # 训练
    model.fit(X_train, y_train, epochs=30, batch_size=16, verbose=0)

    # 预测与反归一化
    y_pred_scaled = model.predict(X_test)
    y_pred = scaler_y.inverse_transform(y_pred_scaled.reshape(-1, 1)).flatten()
    y_true = scaler_y.inverse_transform(y_test.reshape(-1, 1)).flatten()

    # 评估 RMSE
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    print(f"✅ RMSE ({days} days): {rmse:.4f}")
    rmse_results.append((days, rmse))

# ========== 绘图 ==========
if rmse_results:
    days_list, rmse_list = zip(*rmse_results)
    plt.figure(figsize=(8, 5))
    plt.plot(days_list, rmse_list, marker='o')
    plt.title("LSTM Forecast RMSE vs Training Window Size")
    plt.xlabel("Training Window (days)")
    plt.ylabel("RMSE (Next 24h)")
    plt.grid(True)
    plt.xticks(days_list)
    plt.show()
else:
    print("⚠️ No RMSE results to display.")
