import pandas as pd
import numpy as np
import xgboost as xgb
import matplotlib.pyplot as plt
import os
import requests
import glob
from datetime import timedelta, date
from sklearn.metrics import mean_squared_error

# =========================================================
# nRMSE 设置 / nRMSE settings:
#   "max"   -> RMSE / max(y)
#   "mean"  -> RMSE / mean(y)
#   "range" -> RMSE / (max(y) - min(y))
# =========================================================
NORM_METHOD = "max"

# ================= 工具函数：RMSE 与归一化 ================= #
def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray, method: str = NORM_METHOD):
    """
    计算 RMSE 与 nRMSE。返回字典：
      {
        "rmse": float,
        "denom": float,           # 归一化分母
        "nrmse": float or np.nan, # 0~1
        "nrmse_percent": float or np.nan  # 0~100
      }
    """
    rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))
    method = (method or "").lower()

    if method == "max":
        denom = float(np.max(y_true))
    elif method == "mean":
        denom = float(np.mean(y_true))
    elif method == "range":
        denom = float(np.max(y_true) - np.min(y_true))
    else:
        # 未知方法则不归一化
        denom = np.nan

    if denom is None or denom <= 0 or np.isnan(denom):
        nrmse = np.nan
        nrmse_pct = np.nan
    else:
        nrmse = rmse / denom
        nrmse_pct = nrmse * 100.0

    return {
        "rmse": rmse,
        "denom": denom,
        "nrmse": nrmse,
        "nrmse_percent": nrmse_pct
    }

# ================= 1) URL & 下载/清理 ================= #
def get_month_url(year, month, region="SA1"):
    ym = f"{year}{month:02d}"
    return f"https://aemo.com.au/aemo/data/nem/priceanddemand/PRICE_AND_DEMAND_{ym}_{region}.csv"

def download_month_data(year, month, region="SA1", save_folder=r"D:\Python 脚本\aemo_data"):
    os.makedirs(save_folder, exist_ok=True)
    url = get_month_url(year, month, region)
    filename = url.split("/")[-1]
    save_path = os.path.join(save_folder, filename)

    if os.path.exists(save_path):
        print(f"✅ 已存在：{filename}")
        return save_path

    print(f"⬇️ 正在下载：{filename}")
    try:
        resp = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=60)
        if resp.status_code == 200:
            with open(save_path, "wb") as f:
                f.write(resp.content)
            print(f"✅ 下载成功：{filename}")
            return save_path
        else:
            print(f"❌ 下载失败：{filename}（HTTP {resp.status_code}）")
            return None
    except Exception as e:
        print(f"❌ 下载异常：{filename}，原因：{e}")
        return None

def clear_data_folder(folder_path):
    os.makedirs(folder_path, exist_ok=True)
    for f in glob.glob(os.path.join(folder_path, "*.csv")):
        try:
            os.remove(f)
            print(f"🗑️ 已删除旧文件：{f}")
        except Exception as e:
            print(f"⚠️ 删除失败 {f}，原因：{e}")

# ================= 2) 数据准备：清空→当月→不足则加上月 ================= #
def prepare_data():
    data_folder = r"D:\Python 脚本\aemo_data"
    clear_data_folder(data_folder)

    # 计算当月/上月
    today = date.today()
    cur_y, cur_m = today.year, today.month
    prev_m = 12 if cur_m == 1 else cur_m - 1
    prev_y = cur_y - 1 if cur_m == 1 else cur_y

    # 下载当月
    cur_file = download_month_data(cur_y, cur_m, save_folder=data_folder)
    if cur_file is None:
        raise RuntimeError("当月数据下载失败，无法继续。")

    # 读取当月（仅保留必要列）
    need_cols = {"SETTLEMENTDATE", "TOTALDEMAND", "RRP"}
    df_cur = pd.read_csv(cur_file, low_memory=False)
    if not need_cols.issubset(df_cur.columns):
        raise RuntimeError("CSV缺少必要列：需要包含 SETTLEMENTDATE, TOTALDEMAND, RRP")
    df_cur = df_cur[["SETTLEMENTDATE", "TOTALDEMAND", "RRP"]].copy()
    df_cur["SETTLEMENTDATE"] = pd.to_datetime(df_cur["SETTLEMENTDATE"])

    # 判断当月覆盖跨度（小时）
    span_hours = (df_cur["SETTLEMENTDATE"].max() - df_cur["SETTLEMENTDATE"].min()).total_seconds() / 3600.0
    need_prev = span_hours < 7*24 or span_hours < 14*24 or span_hours < 30*24

    if need_prev:
        print("⚠️ 当月数据覆盖不足 7/14/30 天中的至少一个阈值，下载上月进行补齐……")
        prev_file = download_month_data(prev_y, prev_m, save_folder=data_folder)
        if prev_file is not None:
            df_prev = pd.read_csv(prev_file, low_memory=False)
            if need_cols.issubset(df_prev.columns):
                df_prev = df_prev[["SETTLEMENTDATE", "TOTALDEMAND", "RRP"]].copy()
                df_prev["SETTLEMENTDATE"] = pd.to_datetime(df_prev["SETTLEMENTDATE"])
                df = pd.concat([df_prev, df_cur], ignore_index=True)
            else:
                print("⚠️ 上月CSV缺少必要列，将仅使用当月数据。")
                df = df_cur
        else:
            print("⚠️ 上月下载失败，将仅使用当月数据。")
            df = df_cur
    else:
        df = df_cur

    # 统一为小时级（小写 h，避免FutureWarning）
    df = df.sort_values("SETTLEMENTDATE").set_index("SETTLEMENTDATE")
    df = df.resample("h").mean(numeric_only=True)

    # 特征工程
    df["DayOfWeek"] = df.index.dayofweek
    df["HourOfDay"] = df.index.hour
    df["IsWeekend"] = (df["DayOfWeek"] >= 5).astype(int)
    df["Lag24"] = df["TOTALDEMAND"].shift(24)

    df = df.dropna()
    if df.empty:
        raise RuntimeError("清洗后数据为空，请检查下载的CSV内容。")
    return df

# ================= 3) 训练窗口评估（7/14/30天训练误差对比） ================= #
def evaluate_rmse(df, window_days_list=[7, 14, 30]):
    results = []

    latest_time = df.index.max()
    predict_start = latest_time + timedelta(hours=1)
    day_before = predict_start - timedelta(days=1)

    X_predict = df.loc[day_before:day_before + timedelta(hours=23)][["RRP", "TOTALDEMAND"]].copy()
    X_predict.rename(columns={"TOTALDEMAND": "Lag24"}, inplace=True)
    X_predict["DayOfWeek"] = [predict_start.dayofweek] * 24
    X_predict["HourOfDay"] = list(range(24))
    X_predict["IsWeekend"] = [1 if predict_start.dayofweek >= 5 else 0] * 24
    if len(X_predict) < 24:
        print("❌ 预测输入不足24小时，评估环节跳过。")
        return

    for days in window_days_list:
        train_start = latest_time - timedelta(days=days)
        train_end = latest_time
        train_data = df[train_start:train_end].dropna()

        if len(train_data) < days * 24:
            print(f"⚠️ Skipping {days}-day window due to insufficient data.")
            continue

        X_train = train_data[["RRP", "DayOfWeek", "HourOfDay", "IsWeekend", "Lag24"]]
        y_train = train_data["TOTALDEMAND"]

        model = xgb.XGBRegressor(random_state=42)
        model.fit(X_train, y_train)
        y_pred_train = model.predict(X_train)

        # 训练集 RMSE 与 nRMSE
        m = compute_metrics(y_train.values, y_pred_train, method=NORM_METHOD)
        results.append((days, m["rmse"], m["nrmse_percent"]))
        print(
            f"✅ Window {days} days → Training RMSE: {m['rmse']:.4f} | "
            f"nRMSE({NORM_METHOD}) = {m['nrmse_percent']:.2f}%"
        )

    if results:
        windows, rmses, nrmse_pcts = zip(*results)
        plt.figure(figsize=(8, 5))
        plt.plot(windows, rmses, marker="o")
        plt.title("RMSE Comparison Across Different Training Windows (with Lag24)")
        plt.xlabel("Training Days")
        plt.ylabel("Training RMSE")
        plt.grid(True)
        plt.show()

        # 可选：保存一个 CSV 便于留档
        out_df = pd.DataFrame({
            "train_days": windows,
            "train_RMSE": rmses,
            f"train_nRMSE_{NORM_METHOD}_percent": nrmse_pcts
        })
        out_df.to_csv(os.path.join(r"D:\Python 脚本\predict_data", "train_window_rmse.csv"), index=False)
    else:
        print("⚠️ No results available to plot. Possibly due to lack of valid data.")

# ================= 4) 一次性预测：从最新时刻往后24小时 ================= #
def forecast(df):
    latest_time = df.index.max()

    train_start = latest_time - timedelta(days=7)
    train_end = latest_time
    train_data = df[train_start:train_end].dropna()

    if len(train_data) < 7 * 24:
        raise ValueError("❌ Not enough data (7 days) for forecasting.")

    X_train = train_data[["RRP", "DayOfWeek", "HourOfDay", "IsWeekend", "Lag24"]]
    y_train = train_data["TOTALDEMAND"]

    predict_start = latest_time + timedelta(hours=1)
    predict_end = predict_start + timedelta(hours=23)
    day_before = predict_start - timedelta(days=1)

    X_predict = df.loc[day_before:day_before + timedelta(hours=23)][["RRP", "TOTALDEMAND"]].copy()
    X_predict.rename(columns={"TOTALDEMAND": "Lag24"}, inplace=True)
    X_predict["DayOfWeek"] = [predict_start.dayofweek] * 24
    X_predict["HourOfDay"] = list(range(24))
    X_predict["IsWeekend"] = [1 if predict_start.dayofweek >= 5 else 0] * 24

    if len(X_predict) < 24:
        raise ValueError("❌ Failed to retrieve 24 hours of data for prediction.")

    model = xgb.XGBRegressor(random_state=42)
    model.fit(X_train, y_train)

    # 训练集误差（含归一化）
    y_train_pred = model.predict(X_train)
    train_metrics = compute_metrics(y_train.values, y_train_pred, method=NORM_METHOD)
    print(
        f"📉 Training RMSE: {train_metrics['rmse']:.4f} | "
        f"nRMSE({NORM_METHOD}) = {train_metrics['nrmse_percent']:.2f}%"
    )

    # 未来 24 小时预测（无真实值，无法计算当下的 nRMSE）
    y_pred = model.predict(X_predict[["RRP", "DayOfWeek", "HourOfDay", "IsWeekend", "Lag24"]])
    predict_df = pd.DataFrame({
        "Time": pd.date_range(start=predict_start, end=predict_end, freq="h"),
        "Predicted_TOTALDEMAND": y_pred
    })

    output_folder = r"D:\Python 脚本\predict_data"
    os.makedirs(output_folder, exist_ok=True)
    output_path = os.path.join(output_folder, f"prediction_{predict_start.date()}.csv")
    predict_df.to_csv(output_path, index=False)
    print(f"✅ Forecast complete. Results saved to: {output_path}")
    return predict_df

# ================= 5) 改进的滚动：固定7天窗口，滚到最新，统一写一个CSV ================= #
def rolling_to_latest(
    df,
    start_date: pd.Timestamp | None = None,
    output_folder=r"D:\Python 脚本\predict_data",
    train_days:int = 7,
    horizon_hours:int = 24
):
    """
    固定7天训练窗口，从 start_date（若为空则自动推断）一直滚到当前数据可评估的最新日期。
    产物：
      - rolling_predictions_all.csv：汇总所有天的逐小时 真实/预测
      - rolling_metrics.csv：每日RMSE + nRMSE(%)
      - 每天一张 对比图 forecast_YYYY-MM-DD.png
      - daily_rmse_curve.png：RMSE曲线
    """
    os.makedirs(output_folder, exist_ok=True)
    rmse_list = []
    nrmse_list = []
    all_pred_rows = []  # 收集所有天的逐小时预测，最后一次性写CSV

    # 计算可用滚动的时间范围
    latest_time = df.index.max()                                # 数据中最晚的小时
    latest_day_with_truth = (latest_time - pd.Timedelta(hours=horizon_hours-1)).normalize()
    # 自动起点：既要保证有 7 天训练历史，又要从整日开始
    if start_date is None:
        first_possible = (df.index.min() + pd.Timedelta(days=train_days)).normalize()
        start_date = first_possible

    if start_date > latest_day_with_truth:
        print("⚠️ 可评估的最新日期早于起始日期，无法滚动。")
        return

    day_index = pd.date_range(start=start_date, end=latest_day_with_truth, freq="D")
    print(f"📆 Rolling from {start_date.date()} to {latest_day_with_truth.date()}  (train={train_days}d, horizon={horizon_hours}h)")

    for cur_day in day_index:
        # 训练区间：过去7天（不含当前日）
        train_end = cur_day - pd.Timedelta(hours=1)
        train_start = train_end - pd.Timedelta(days=train_days)
        train_data = df[train_start:train_end].dropna()

        if len(train_data) < train_days * 24:
            print(f"⚠️ {cur_day.date()}：训练数据不足（{len(train_data)}小时），跳过。")
            continue

        X_train = train_data[["RRP", "DayOfWeek", "HourOfDay", "IsWeekend", "Lag24"]]
        y_train = train_data["TOTALDEMAND"]

        # 预测窗口：当日00:00 ~ 23:00
        predict_start = cur_day
        predict_end = cur_day + pd.Timedelta(hours=horizon_hours-1)

        # 预测输入：用“前一日24小时”的RRP+TOTALDEMAND构造 Lag24
        prev_day = df[predict_start - pd.Timedelta(days=1): predict_start - pd.Timedelta(days=1) + pd.Timedelta(hours=horizon_hours-1)]
        if len(prev_day) < horizon_hours:
            print(f"⚠️ {cur_day.date()}：预测输入不足{horizon_hours}小时（prev={len(prev_day)}），跳过。")
            continue

        X_predict = prev_day[["RRP", "TOTALDEMAND"]].copy()
        X_predict.rename(columns={"TOTALDEMAND": "Lag24"}, inplace=True)
        X_predict["DayOfWeek"] = [predict_start.dayofweek] * horizon_hours
        X_predict["HourOfDay"] = list(range(horizon_hours))
        X_predict["IsWeekend"] = [1 if predict_start.dayofweek >= 5 else 0] * horizon_hours

        # 真实值
        y_true_series = df[predict_start:predict_end]["TOTALDEMAND"]
        if len(y_true_series) < horizon_hours:
            print(f"⚠️ {cur_day.date()}：真实值不足{horizon_hours}小时（y_true={len(y_true_series)}），跳过。")
            continue
        y_true = y_true_series.values

        # 训练并预测
        model = xgb.XGBRegressor(random_state=42)
        model.fit(X_train, y_train)
        y_pred = model.predict(X_predict[["RRP", "DayOfWeek", "HourOfDay", "IsWeekend", "Lag24"]])

        # 评价：RMSE + nRMSE(%)
        m = compute_metrics(y_true, y_pred, method=NORM_METHOD)
        rmse_list.append((cur_day.date(), float(m["rmse"])))
        nrmse_list.append((cur_day.date(), float(m["nrmse_percent"]) if not np.isnan(m["nrmse_percent"]) else np.nan))
        print(f"✅ {cur_day.date()} RMSE: {m['rmse']:.4f} | nRMSE({NORM_METHOD}): {m['nrmse_percent']:.2f}%")

        # 累积保存（不逐日写文件，最后一次性写一个CSV）
        time_index = pd.date_range(start=predict_start, end=predict_end, freq="h")
        all_pred_rows.append(pd.DataFrame({
            "Date": [cur_day.date()] * horizon_hours,
            "Time": time_index,
            "Actual_TOTALDEMAND": y_true,
            "Pred_TOTALDEMAND": y_pred
        }))

        # 每日图
        plt.figure(figsize=(10, 5))
        plt.plot(range(horizon_hours), y_true, label="Actual")
        plt.plot(range(horizon_hours), y_pred, label="Predicted")
        plt.title(f"Forecast vs Actual for {cur_day.date()}")
        plt.xlabel("Hour")
        plt.ylabel("TOTALDEMAND")
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(output_folder, f"forecast_{cur_day.date()}.png"))
        plt.close()

    # 汇总写出
    if all_pred_rows:
        all_preds = pd.concat(all_pred_rows, ignore_index=True)
        all_preds.to_csv(os.path.join(output_folder, "rolling_predictions_all.csv"), index=False)

        dates_r, rmses = zip(*rmse_list)
        # 若 nRMSE 列表非空，则与日期对齐
        dates_n, nrmse_pcts = zip(*nrmse_list)

        # RMSE曲线
        plt.figure(figsize=(10, 5))
        plt.plot(dates_r, rmses, marker='o', linestyle='-')
        plt.title("Daily Forecast RMSE (Next 24h)")
        plt.xlabel("Date")
        plt.ylabel("RMSE")
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(os.path.join(output_folder, "daily_rmse_curve.png"))
        plt.show()

        # 指标 CSV（包含 nRMSE%）
        pd.DataFrame({
            "Date": dates_r,
            "RMSE": rmses,
            f"nRMSE_{NORM_METHOD}_percent": nrmse_pcts
        }).to_csv(os.path.join(output_folder, "rolling_metrics.csv"), index=False)
    else:
        print("⚠️ 无有效滚动结果（可能因为数据不足而全部跳过）。")

# ================= 6) 主程序 ================= #
if __name__ == "__main__":
    df = prepare_data()

    # 训练窗口拟合评估（可选）
    evaluate_rmse(df, window_days_list=[7, 14, 30])

    # 逐日滚动：固定7天窗口，从自动推断的最早可评估日滚到“可拿到完整24小时真实值”的最新日
    rolling_to_latest(df)

    # 如需再生成一次“从最新时刻往后24h”的预测文件（可选）
    forecast(df)
