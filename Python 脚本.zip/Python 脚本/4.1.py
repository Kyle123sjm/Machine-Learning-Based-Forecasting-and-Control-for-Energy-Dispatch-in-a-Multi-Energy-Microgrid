# -*- coding: utf-8 -*-
"""
XGBoost 24h 负荷预测（节假日细分 + 历史/预报天气，按小时）
- 训练：AEMO + 历史（archive）天气（严格对齐）
- 预测：用 forecast 天气补齐目标日 24h
- 特征：
  RRP, DayOfWeek, HourOfDay, IsWeekend, Lag24,
  IsHoliday, IsPublicHoliday, IsSchoolHoliday,
  Temp2m, RH2m, ApparentTemp, CloudCoverTotal, WindSpeed10m
"""

import os
import re
import glob
import pandas as pd
import numpy as np
import xgboost as xgb
import matplotlib.pyplot as plt
import requests
from io import StringIO
from datetime import datetime, date, time, timedelta
from typing import List, Tuple, Dict, Union
from sklearn.metrics import mean_squared_error

# ================= 配置区 =================
NORM_METHOD    = "max"
DATA_FOLDER     = r"D:\Python 脚本\aemo_data"
OUTPUT_FOLDER   = r"D:\Python 脚本\predict_data"
HOLIDAY_PATH    = r"D:\Python 脚本\holiday"

# 天气（阿德莱德）
WEATHER_ARCHIVE_FOLDER  = r"D:\Python 脚本\API"
WEATHER_ARCHIVE_FILE    = os.path.join(WEATHER_ARCHIVE_FOLDER, "openmeteo_archive_20250101_20250818.csv")
WEATHER_ARCHIVE_URL     = (
    "https://archive-api.open-meteo.com/v1/archive"
    "?latitude=-34.9287&longitude=138.5986"
    "&start_date=2025-01-01&end_date=2025-08-18"
    "&hourly=temperature_2m,relative_humidity_2m,apparent_temperature,cloud_cover,wind_speed_10m"
    "&format=csv"
)

WEATHER_FORECAST_FOLDER = r"D:\Python 脚本\API_forecast"
WEATHER_FORECAST_FILE   = os.path.join(WEATHER_FORECAST_FOLDER, "openmeteo_forecast_past1_future1.csv")
WEATHER_FORECAST_URL    = (
    "https://api.open-meteo.com/v1/forecast"
    "?latitude=-34.9214&longitude=138.6075"
    "&hourly=temperature_2m,relative_humidity_2m,apparent_temperature,cloud_cover,wind_speed_10m"
    "&past_days=1&forecast_days=1&format=csv"
)

# 统一天气列名（解析后映射到模型特征名）
WEATHER_COL_MAP = {
    "temperature_2m":       "Temp2m",
    "relative_humidity_2m": "RH2m",
    "apparent_temperature": "ApparentTemp",
    "cloud_cover":          "CloudCoverTotal",
    "cloudcover":           "CloudCoverTotal",   # 兼容无下划线写法
    "wind_speed_10m":       "WindSpeed10m",
    "windspeed_10m":        "WindSpeed10m",      # 兼容无下划线写法
}
WEATHER_FEATURES = ["Temp2m","RH2m","ApparentTemp","CloudCoverTotal","WindSpeed10m"]

# ============== 指标函数 ==============
def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray, method: str = NORM_METHOD):
    rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))
    method = (method or "").lower()
    if method == "max":
        denom = float(np.max(y_true))
    elif method == "mean":
        denom = float(np.mean(y_true))
    elif method == "range":
        denom = float(np.max(y_true) - np.min(y_true))
    else:
        denom = np.nan
    if denom is None or denom <= 0 or np.isnan(denom):
        nrmse = np.nan; nrmse_pct = np.nan
    else:
        nrmse = rmse / denom; nrmse_pct = nrmse * 100.0
    return {"rmse": rmse, "denom": denom, "nrmse": nrmse, "nrmse_percent": nrmse_pct}

# ============== 假期解析（细分 + 按小时） ==============
_HOLIDAY_CACHE: Dict[str, Dict[str, List[Tuple[datetime, datetime]]]] = {}

def _iter_holiday_csvs(path_or_folder: str):
    if os.path.isfile(path_or_folder):
        yield path_or_folder
    elif os.path.isdir(path_or_folder):
        for fp in glob.glob(os.path.join(path_or_folder, "*.csv")):
            yield fp
    else:
        print(f"⚠️ 找不到节假日路径：{path_or_folder}")

def _safe_dt(d_str, t_str, is_end=False, all_day=True):
    d = pd.to_datetime(d_str, errors="coerce")
    if pd.isna(d):
        return None
    d = d.to_pydatetime().date()
    if (t_str is None) or (isinstance(t_str, float) and np.isnan(t_str)) or (str(t_str).strip() == ""):
        if all_day:
            return datetime.combine(d + timedelta(days=1), time(0, 0)) if is_end else datetime.combine(d, time(0, 0))
        else:
            return datetime.combine(d + timedelta(days=1), time(0, 0)) if is_end else datetime.combine(d, time(0, 0))
    else:
        s = str(t_str).strip()
        for fmt in ("%H:%M", "%H:%M:%S"):
            try:
                t = datetime.strptime(s, fmt).time()
                break
            except Exception:
                t = None
        if t is None:
            t = time(23, 59, 59) if is_end else time(0, 0)
        return datetime.combine(d, t)

def load_holiday_intervals(path_or_folder: str) -> Dict[str, List[Tuple[datetime, datetime]]]:
    if path_or_folder in _HOLIDAY_CACHE:
        return _HOLIDAY_CACHE[path_or_folder]
    intervals_all: List[Tuple[datetime, datetime]] = []
    intervals_public: List[Tuple[datetime, datetime]] = []
    intervals_school: List[Tuple[datetime, datetime]] = []
    n_files = 0; n_rows = 0
    for fp in _iter_holiday_csvs(path_or_folder):
        n_files += 1
        try: df = pd.read_csv(fp)
        except Exception: df = pd.read_csv(fp, encoding="utf-8-sig")
        cols = {c.lower(): c for c in df.columns}
        start_col = next((cols[k] for k in ["start_datetime","start_dt","start","start date","start_date"] if k in cols), None)
        end_col   = next((cols[k] for k in ["end_datetime","end_dt","end","end date","end_date"] if k in cols), None)
        type_col  = next((cols[k] for k in ["type","category","kind"] if k in cols), None)
        all_day_col = next((cols[k] for k in ["all_day","allday","is_all_day"] if k in cols), None)
        stime_col = next((cols[k] for k in ["start_time","stime","start time"] if k in cols), None)
        etime_col = next((cols[k] for k in ["end_time","etime","end time"] if k in cols), None)
        if start_col is None and "start_date" in cols: start_col = cols["start_date"]
        if end_col   is None and "end_date"   in cols: end_col   = cols["end_date"]
        if start_col is None or end_col is None:
            date_like_cols = [c for c in df.columns if "date" in c.lower()]
            if len(date_like_cols) >= 2: start_col, end_col = date_like_cols[:2]
            else: print(f"⚠️ {fp} 缺少可解析的起止列，跳过。"); continue
        for _, row in df.iterrows():
            all_day = True
            if all_day_col is not None and all_day_col in row:
                try: all_day = bool(row[all_day_col])
                except Exception: all_day = True
            st = _safe_dt(row[start_col], row[stime_col] if (stime_col in df.columns) else None, is_end=False, all_day=all_day)
            ed = _safe_dt(row[end_col],   row[etime_col] if (etime_col in df.columns) else None, is_end=True,  all_day=all_day)
            if st is None or ed is None: continue
            if ed <= st: ed = st + timedelta(hours=1)
            typ = str(row[type_col]).strip().lower() if type_col is not None else ""
            intervals_all.append((st, ed))
            if "school" in typ: intervals_school.append((st, ed))
            elif "public" in typ: intervals_public.append((st, ed))
            n_rows += 1
    print(f"🗓️ 已加载假期区间 {len(intervals_all)} 条，来自 {n_files} 个CSV（原始行 {n_rows}）。")
    result = {"all": intervals_all, "public": intervals_public, "school": intervals_school}
    _HOLIDAY_CACHE[path_or_folder] = result
    return result

def _mark_hours_by_intervals(hourly_index: pd.DatetimeIndex, intervals: List[Tuple[datetime, datetime]]) -> np.ndarray:
    if len(hourly_index) == 0 or len(intervals) == 0:
        return np.zeros(len(hourly_index), dtype=int)
    mark = np.zeros(len(hourly_index), dtype=int)
    for (st, ed) in intervals:
        left  = hourly_index >= pd.Timestamp(st)
        right = hourly_index <  pd.Timestamp(ed)
        idx = np.where(left & right)[0]
        if len(idx) > 0:
            mark[idx] = 1
    return mark

def add_holiday_features(df: pd.DataFrame, holiday_path: str) -> pd.DataFrame:
    intervals = load_holiday_intervals(holiday_path)
    idx = df.index
    public_vec = _mark_hours_by_intervals(idx, intervals["public"])
    school_vec = _mark_hours_by_intervals(idx, intervals["school"])
    all_vec    = np.clip(public_vec + school_vec, 0, 1)
    df["IsPublicHoliday"] = public_vec
    df["IsSchoolHoliday"] = school_vec
    df["IsHoliday"]       = all_vec
    return df

def make_holiday_vectors(start_ts: pd.Timestamp, hours: int, holiday_path: str):
    intervals = load_holiday_intervals(holiday_path)
    times = pd.date_range(start=start_ts, periods=hours, freq="h")
    public_vec = _mark_hours_by_intervals(times, intervals["public"])
    school_vec = _mark_hours_by_intervals(times, intervals["school"])
    all_vec    = np.clip(public_vec + school_vec, 0, 1)
    return all_vec, public_vec, school_vec

# ============== AEMO 下载与准备 ==============
def get_month_url(year, month, region="SA1"):
    ym = f"{year}{month:02d}"
    return f"https://aemo.com.au/aemo/data/nem/priceanddemand/PRICE_AND_DEMAND_{ym}_{region}.csv"

def download_month_data(year, month, region="SA1", save_folder: str = DATA_FOLDER):
    os.makedirs(save_folder, exist_ok=True)
    url = get_month_url(year, month, region)
    filename = url.split("/")[-1]
    save_path = os.path.join(save_folder, filename)
    if os.path.exists(save_path):
        print(f"✅ 已存在：{filename}")
        return save_path
    print(f"⬇️ 正在下载：{filename}")
    try:
        resp = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=60)
        if resp.status_code == 200:
            with open(save_path, "wb") as f:
                f.write(resp.content)
            print(f"✅ 下载成功：{filename}")
            return save_path
        else:
            print(f"❌ 下载失败：{filename}（HTTP {resp.status_code}）")
            return None
    except Exception as e:
        print(f"❌ 下载异常：{filename}，原因：{e}")
        return None

def clear_data_folder(folder_path: str):
    os.makedirs(folder_path, exist_ok=True)
    for f in glob.glob(os.path.join(folder_path, "*.csv")):
        try:
            os.remove(f)
            print(f"🗑️ 已删除旧文件：{f}")
        except Exception as e:
            print(f"⚠️ 删除失败 {f}，原因：{e}")

# ============== 天气下载/读取（历史 & 预报） ==============
def _append_tz_param(url: str, tz: str = "Australia/Adelaide") -> str:
    # 若无 timezone 参数则追加（Open-Meteo CSV 默认 UTC；建议指定与 AEMO 一致的本地时区）
    if "timezone=" in url:
        return url
    sep = "&" if "?" in url else "?"
    return f"{url}{sep}timezone={tz.replace('/', '%2F')}"

def _download_to(path: str, url: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    print(f"⬇️ 下载：{url}")
    r = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=120)
    r.raise_for_status()
    with open(path, "wb") as f:
        f.write(r.content)
    print(f"✅ 保存：{path}")

def download_archive_weather(force: bool = False) -> str:
    url = _append_tz_param(WEATHER_ARCHIVE_URL)
    if (not force) and os.path.exists(WEATHER_ARCHIVE_FILE):
        print(f"✅ 历史天气已存在：{WEATHER_ARCHIVE_FILE}")
        return WEATHER_ARCHIVE_FILE
    _download_to(WEATHER_ARCHIVE_FILE, url)
    return WEATHER_ARCHIVE_FILE

def download_forecast_weather() -> str:
    url = _append_tz_param(WEATHER_FORECAST_URL)
    _download_to(WEATHER_FORECAST_FILE, url)
    return WEATHER_FORECAST_FILE

def _load_weather_csv(csv_path: str) -> pd.DataFrame:
    """
    兼容 Open-Meteo CSV 的“两行表头”与普通一行表头：
    - 若第一行是 metadata，第二行才是列名（含单位），则用第二行作为表头，去掉单位括号；
    - 自动识别时间列（time / time (...) / date / timestamp）并标准化为 DatetimeIndex；
    - 仅保留并映射到我们需要的特征列（WEATHER_FEATURES）。
    """
    df_raw = pd.read_csv(csv_path, dtype=str, keep_default_na=False)

    # 情况 A：两行表头（第一列是 latitude，第二行第一列是 time）
    two_row_header = (
        len(df_raw) >= 2 and
        df_raw.columns[0].strip().lower() in {"latitude", "lat"} and
        str(df_raw.iloc[1, 0]).strip().lower().startswith("time")
    )

    if two_row_header:
        # 第二行为列名，去掉单位括号
        def strip_unit(s: str) -> str:
            return re.sub(r"\s*\(.*?\)\s*$", "", str(s)).strip()
        new_cols = [strip_unit(c) for c in list(df_raw.iloc[1, :])]
        df = df_raw.iloc[2:, :].copy()
        df.columns = new_cols
    else:
        # 情况 B：普通一行表头
        df = pd.read_csv(csv_path)

    # 找到时间列（可能叫 time, time (UTC), time (Australia/Adelaide), date, timestamp）
    time_col = None
    for c in df.columns:
        if str(c).strip().lower().startswith("time"):
            time_col = c; break
    if time_col is None:
        for cand in ["timestamp", "date", "time (utc)", "time (australia/adelaide)"]:
            if cand in df.columns:
                time_col = cand; break
    if time_col is None:
        raise RuntimeError("天气CSV里没有找到时间列，请检查文件！")

    if time_col != "time":
        df = df.rename(columns={time_col: "time"})
    df["time"] = pd.to_datetime(df["time"], errors="coerce")
    df = df.dropna(subset=["time"]).set_index("time").sort_index()

    # 字段名标准化（兼容 cloudcover / windspeed_10m）
    rename_candidates = {}
    cols_lower = {c.lower(): c for c in df.columns}
    if "cloudcover" in cols_lower and "cloud_cover" not in cols_lower:
        rename_candidates[cols_lower["cloudcover"]] = "cloud_cover"
    if "windspeed_10m" in cols_lower and "wind_speed_10m" not in cols_lower:
        rename_candidates[cols_lower["windspeed_10m"]] = "wind_speed_10m"
    if rename_candidates:
        df = df.rename(columns=rename_candidates)

    # 只保留需要的列（按原始名）
    needed_raw = ["temperature_2m","relative_humidity_2m","apparent_temperature","cloud_cover","wind_speed_10m",
                  "cloudcover","windspeed_10m"]
    existing = [c for c in needed_raw if c in df.columns]
    if not existing:
        raise RuntimeError("天气CSV中找不到所需的小时变量。")

    # 映射到模型特征名
    keep_renamed = {}
    for raw_col in existing:
        std_col = WEATHER_COL_MAP.get(raw_col)
        if std_col is not None:
            keep_renamed[raw_col] = std_col
    df = df[list(keep_renamed.keys())].rename(columns=keep_renamed)

    # 严格小时频率 + 数值化 + 微小空洞插补
    df = df.asfreq("h")
    for c in df.columns:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.interpolate(limit_direction="both").ffill().bfill()

    # 如需把风速从 km/h 转 m/s（可选）：df["WindSpeed10m"] = df["WindSpeed10m"] / 3.6
    return df

# ============== 组合训练数据（AEMO + 历史天气） ==============
def prepare_data() -> pd.DataFrame:
    # 1) AEMO
    clear_data_folder(DATA_FOLDER)
    today = date.today()
    cur_y, cur_m = today.year, today.month
    prev_m = 12 if cur_m == 1 else cur_m - 1
    prev_y = cur_y - 1 if cur_m == 1 else cur_y

    cur_file = download_month_data(cur_y, cur_m, save_folder=DATA_FOLDER)
    if cur_file is None:
        raise RuntimeError("当月数据下载失败，无法继续。")

    need_cols = {"SETTLEMENTDATE", "TOTALDEMAND", "RRP"}
    df_cur = pd.read_csv(cur_file, low_memory=False)
    if not need_cols.issubset(df_cur.columns):
        raise RuntimeError("CSV缺少必要列：需要包含 SETTLEMENTDATE, TOTALDEMAND, RRP")
    df_cur = df_cur[["SETTLEMENTDATE", "TOTALDEMAND", "RRP"]].copy()
    df_cur["SETTLEMENTDATE"] = pd.to_datetime(df_cur["SETTLEMENTDATE"])

    span_hours = (df_cur["SETTLEMENTDATE"].max() - df_cur["SETTLEMENTDATE"].min()).total_seconds() / 3600.0
    need_prev = span_hours < 7*24 or span_hours < 14*24 or span_hours < 30*24

    if need_prev:
        print("⚠️ 当月数据覆盖不足，下载上月进行补齐……")
        prev_file = download_month_data(prev_y, prev_m, save_folder=DATA_FOLDER)
        if prev_file is not None:
            df_prev = pd.read_csv(prev_file, low_memory=False)
            if need_cols.issubset(df_prev.columns):
                df_prev = df_prev[["SETTLEMENTDATE", "TOTALDEMAND", "RRP"]].copy()
                df_prev["SETTLEMENTDATE"] = pd.to_datetime(df_prev["SETTLEMENTDATE"])
                df = pd.concat([df_prev, df_cur], ignore_index=True)
            else:
                print("⚠️ 上月CSV缺少必要列，将仅使用当月数据。")
                df = df_cur
        else:
            print("⚠️ 上月下载失败，将仅使用当月数据。")
            df = df_cur
    else:
        df = df_cur

    # 小时聚合
    df = df.sort_values("SETTLEMENTDATE").set_index("SETTLEMENTDATE")
    df = df.resample("h").mean(numeric_only=True)

    # 时间/滞后/节假日
    df["DayOfWeek"] = df.index.dayofweek
    df["HourOfDay"] = df.index.hour
    df["IsWeekend"] = (df["DayOfWeek"] >= 5).astype(int)
    df["Lag24"] = df["TOTALDEMAND"].shift(24)
    df = add_holiday_features(df, HOLIDAY_PATH)

    # 2) 历史天气（只用于训练/回测）
    archive_path = download_archive_weather(force=False)
    df_archive = _load_weather_csv(archive_path)
    df = df.join(df_archive, how="left").dropna()

    if df.empty:
        raise RuntimeError("清洗/合并后数据为空，请检查时间对齐与文件内容。")
    return df

# 公共特征列
FEATURE_COLS = [
    "RRP","DayOfWeek","HourOfDay","IsWeekend","Lag24",
    "IsHoliday","IsPublicHoliday","IsSchoolHoliday",
    "Temp2m","RH2m","ApparentTemp","CloudCoverTotal","WindSpeed10m"
]

# ============== 训练窗评估 ==============
def evaluate_rmse(df: pd.DataFrame, window_days_list=[7, 14, 30]):
    results = []
    latest_time = df.index.max()
    for days in window_days_list:
        train_start = latest_time - timedelta(days=days)
        train_end   = latest_time
        train_data  = df[train_start:train_end].dropna()
        if len(train_data) < days * 24:
            print(f"⚠️ Skipping {days}-day window due to insufficient data.")
            continue

        X_train = train_data[FEATURE_COLS]
        y_train = train_data["TOTALDEMAND"]

        model = xgb.XGBRegressor(random_state=42)
        model.fit(X_train, y_train)
        y_pred_train = model.predict(X_train)

        m = compute_metrics(y_train.values, y_pred_train, method=NORM_METHOD)
        results.append((days, m["rmse"], m["nrmse_percent"]))
        print(f"✅ Window {days} days → Training RMSE: {m['rmse']:.4f} | nRMSE({NORM_METHOD}) = {m['nrmse_percent']:.2f}%")

    if results:
        windows, rmses, nrmse_pcts = zip(*results)
        plt.figure(figsize=(8, 5))
        plt.plot(windows, rmses, marker="o")
        plt.title("RMSE Across Training Windows (With Weather)")
        plt.xlabel("Training Days"); plt.ylabel("Training RMSE"); plt.grid(True); plt.show()

        os.makedirs(OUTPUT_FOLDER, exist_ok=True)
        pd.DataFrame({
            "train_days": windows,
            "train_RMSE": rmses,
            f"train_nRMSE_{NORM_METHOD}_percent": nrmse_pcts
        }).to_csv(os.path.join(OUTPUT_FOLDER, "train_window_rmse.csv"), index=False)
    else:
        print("⚠️ No results to plot.")

# ============== 一次性未来24h预测（用 forecast 天气） ==============
def forecast(df: pd.DataFrame) -> pd.DataFrame:
    latest_time = df.index.max()
    train_data  = df[latest_time - timedelta(days=7): latest_time].dropna()
    if len(train_data) < 7*24:
        raise ValueError("❌ Not enough data (7 days) for forecasting.")

    X_train = train_data[FEATURE_COLS]
    y_train = train_data["TOTALDEMAND"]

    predict_start = latest_time + timedelta(hours=1)
    predict_end   = predict_start + timedelta(hours=23)
    day_before    = predict_start - timedelta(days=1)

    # 基础输入：Lag24/日历/节假日（Lag24 来自前一日真实负荷）
    X_predict = df.loc[day_before: day_before + timedelta(hours=23)][["RRP","TOTALDEMAND"]].copy()
    if len(X_predict) < 24:
        raise ValueError("❌ Failed to retrieve 24 hours of base inputs for prediction.")
    X_predict.rename(columns={"TOTALDEMAND":"Lag24"}, inplace=True)
    X_predict["DayOfWeek"] = [predict_start.dayofweek] * 24
    X_predict["HourOfDay"] = list(range(24))
    X_predict["IsWeekend"] = [1 if predict_start.dayofweek >= 5 else 0] * 24
    iso_all, iso_pub, iso_sch = make_holiday_vectors(predict_start, 24, HOLIDAY_PATH)
    X_predict["IsHoliday"]       = iso_all
    X_predict["IsPublicHoliday"] = iso_pub
    X_predict["IsSchoolHoliday"] = iso_sch

    # 预报天气（补目标日 24h）
    fc_path = download_forecast_weather()
    df_fc = _load_weather_csv(fc_path)
    full_idx = pd.date_range(start=predict_start, end=predict_end, freq="h")
    wx = df_fc.reindex(full_idx).interpolate(limit_direction="both").ffill().bfill()
    if len(wx) < 24:
        raise RuntimeError("❌ 预报天气未覆盖预测日24小时，请检查 forecast_days/past_days 或时间对齐。")
    for c in WEATHER_FEATURES:
        X_predict[c] = wx[c].values

    # 训练并预测
    model = xgb.XGBRegressor(random_state=42)
    model.fit(X_train, y_train)

    y_train_pred  = model.predict(X_train)
    train_metrics = compute_metrics(y_train.values, y_train_pred, method=NORM_METHOD)
    print(f"📉 Training RMSE: {train_metrics['rmse']:.4f} | nRMSE({NORM_METHOD}) = {train_metrics['nrmse_percent']:.2f}%")

    y_pred = model.predict(X_predict[FEATURE_COLS])
    predict_df = pd.DataFrame({
        "Time": pd.date_range(start=predict_start, end=predict_end, freq="h"),
        "Predicted_TOTALDEMAND": y_pred
    })
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)
    out_path = os.path.join(OUTPUT_FOLDER, f"prediction_{predict_start.date()}.csv")
    predict_df.to_csv(out_path, index=False)
    print(f"✅ Forecast complete. Results saved to: {out_path}")
    return predict_df

# ============== 逐日滚动（历史回测，仅用历史天气） ==============
def rolling_to_latest(
    df: pd.DataFrame,
    start_date: Union[pd.Timestamp, None] = None,
    output_folder: str = OUTPUT_FOLDER,
    train_days: int = 7,
    horizon_hours: int = 24
):
    os.makedirs(output_folder, exist_ok=True)
    rmse_list, nrmse_list, all_pred_rows = [], [], []

    latest_time = df.index.max()
    latest_day_with_truth = (latest_time - pd.Timedelta(hours=horizon_hours-1)).normalize()

    if start_date is None:
        start_date = (df.index.min() + pd.Timedelta(days=train_days)).normalize()
    if start_date > latest_day_with_truth:
        print("⚠️ 可评估的最新日期早于起始日期，无法滚动。"); return

    print(f"📆 Rolling from {start_date.date()} to {latest_day_with_truth.date()} (train={train_days}d, horizon={horizon_hours}h)")

    for cur_day in pd.date_range(start=start_date, end=latest_day_with_truth, freq="D"):
        train_end   = cur_day - pd.Timedelta(hours=1)
        train_start = train_end - pd.Timedelta(days=train_days)
        train_data  = df[train_start:train_end].dropna()
        if len(train_data) < train_days * 24:
            print(f"⚠️ {cur_day.date()}：训练数据不足（{len(train_data)}小时），跳过。"); continue

        X_train = train_data[FEATURE_COLS]
        y_train = train_data["TOTALDEMAND"]

        predict_start = cur_day
        predict_end   = cur_day + pd.Timedelta(hours=horizon_hours-1)

        prev_day = df[predict_start - pd.Timedelta(days=1): predict_start - pd.Timedelta(days=1) + pd.Timedelta(hours=horizon_hours-1)]
        if len(prev_day) < horizon_hours:
            print(f"⚠️ {cur_day.date()}：预测输入不足{horizon_hours}小时（prev={len(prev_day)}），跳过。"); continue

        X_predict = prev_day[["RRP","TOTALDEMAND"]].copy()
        X_predict.rename(columns={"TOTALDEMAND":"Lag24"}, inplace=True)
        X_predict["DayOfWeek"] = [predict_start.dayofweek] * horizon_hours
        X_predict["HourOfDay"] = list(range(horizon_hours))
        X_predict["IsWeekend"] = [1 if predict_start.dayofweek >= 5 else 0] * horizon_hours
        iso_all, iso_pub, iso_sch = make_holiday_vectors(predict_start, horizon_hours, HOLIDAY_PATH)
        X_predict["IsHoliday"]       = iso_all
        X_predict["IsPublicHoliday"] = iso_pub
        X_predict["IsSchoolHoliday"] = iso_sch

        # 当天 24h 的历史天气（已在 df 中）
        wx_slice = df.loc[predict_start:predict_end][WEATHER_FEATURES]
        if len(wx_slice) < horizon_hours:
            print(f"⚠️ {cur_day.date()}：当天天气特征不足{horizon_hours}小时，跳过。"); continue
        for c in WEATHER_FEATURES:
            X_predict[c] = wx_slice[c].values

        # 真实值
        y_true_series = df[predict_start:predict_end]["TOTALDEMAND"]
        if len(y_true_series) < horizon_hours:
            print(f"⚠️ {cur_day.date()}：真实值不足{horizon_hours}小时（y_true={len(y_true_series)}），跳过。"); continue
        y_true = y_true_series.values

        model = xgb.XGBRegressor(random_state=42)
        model.fit(X_train, y_train)
        y_pred = model.predict(X_predict[FEATURE_COLS])

        m = compute_metrics(y_true, y_pred, method=NORM_METHOD)
        rmse_list.append((cur_day.date(), float(m["rmse"])))
        nrmse_list.append((cur_day.date(), float(m["nrmse_percent"]) if not np.isnan(m["nrmse_percent"]) else np.nan))
        print(f"✅ {cur_day.date()} RMSE: {m['rmse']:.4f} | nRMSE({NORM_METHOD}): {m['nrmse_percent']:.2f}%")

        time_index = pd.date_range(start=predict_start, end=predict_end, freq="h")
        all_pred_rows.append(pd.DataFrame({
            "Date": [cur_day.date()] * horizon_hours,
            "Time": time_index,
            "Actual_TOTALDEMAND": y_true,
            "Pred_TOTALDEMAND": y_pred
        }))

        plt.figure(figsize=(10, 5))
        plt.plot(range(horizon_hours), y_true, label="Actual")
        plt.plot(range(horizon_hours), y_pred, label="Predicted")
        plt.title(f"Forecast vs Actual for {cur_day.date()}")
        plt.xlabel("Hour"); plt.ylabel("TOTALDEMAND"); plt.legend()
        plt.tight_layout(); plt.savefig(os.path.join(output_folder, f"forecast_{cur_day.date()}.png")); plt.close()

    if all_pred_rows:
        all_preds = pd.concat(all_pred_rows, ignore_index=True)
        all_preds.to_csv(os.path.join(output_folder, "rolling_predictions_all.csv"), index=False)

        dates_r, rmses = zip(*rmse_list)
        dates_n, nrmse_pcts = zip(*nrmse_list)

        plt.figure(figsize=(10, 5))
        plt.plot(dates_r, rmses, marker='o', linestyle='-')
        plt.title("Daily Forecast RMSE (Next 24h)")
        plt.xlabel("Date"); plt.ylabel("RMSE"); plt.grid(True)
        plt.tight_layout(); plt.savefig(os.path.join(output_folder, "daily_rmse_curve.png")); plt.show()

        pd.DataFrame({
            "Date": dates_r,
            "RMSE": rmses,
            f"nRMSE_{NORM_METHOD}_percent": nrmse_pcts
        }).to_csv(os.path.join(output_folder, "rolling_metrics.csv"), index=False)
    else:
        print("⚠️ 无有效滚动结果（可能因为数据不足而全部跳过）。")

# ============== 主程序 ==============
if __name__ == "__main__":
    df = prepare_data()
    evaluate_rmse(df, window_days_list=[7, 14, 30])  # 可选
    rolling_to_latest(df)                             # 核心（历史回测）
    forecast(df)                                      # 可选：用预报天气预测下一日
