import pandas as pd
import numpy as np
import xgboost as xgb
import matplotlib.pyplot as plt
import os
import requests
import glob
from datetime import timedelta, date
from sklearn.metrics import mean_squared_error

def get_month_url(year, month, region="SA1"):
    ym = f"{year}{month:02d}"
    return f"https://aemo.com.au/aemo/data/nem/priceanddemand/PRICE_AND_DEMAND_{ym}_{region}.csv"

def download_month_data(year, month, region="SA1", save_folder=r"D:\Python 脚本\aemo_data"):
    url = get_month_url(year, month, region)
    filename = url.split("/")[-1]
    save_path = os.path.join(save_folder, filename)
    headers = {"User-Agent": "Mozilla/5.0"}
    os.makedirs(save_folder, exist_ok=True)
    if os.path.exists(save_path):
        print(f"📁 文件已存在：{save_path}")
        return save_path
    print(f"🌐 开始下载：{url}")
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        with open(save_path, "wb") as f:
            f.write(response.content)
        print(f"✅ 下载成功：{save_path}")
        return save_path
    else:
        print(f"❌ 下载失败：{url}")
        return None

def clear_data_folder(folder_path):
    csv_files = glob.glob(os.path.join(folder_path, "*.csv"))
    for f in csv_files:
        try:
            os.remove(f)
            print(f"🗑️ 已删除旧文件：{f}")
        except Exception as e:
            print(f"⚠️ 删除失败：{f}，原因：{e}")

def prepare_data():
    data_folder = r"D:\Python 脚本\aemo_data"
    clear_data_folder(data_folder)
    today = date.today()
    current_year, current_month = today.year, today.month
    last_month = 12 if current_month == 1 else current_month - 1
    last_year = current_year - 1 if current_month == 1 else current_year

    current_file = download_month_data(current_year, current_month, save_folder=data_folder)
    df_current = pd.read_csv(current_file)
    df_current = df_current[['SETTLEMENTDATE', 'TOTALDEMAND', 'RRP']]
    df_current['SETTLEMENTDATE'] = pd.to_datetime(df_current['SETTLEMENTDATE'])

    latest_time = df_current['SETTLEMENTDATE'].max()
    earliest_time = df_current['SETTLEMENTDATE'].min()

    # ✅ 修正判断逻辑
    if (latest_time - earliest_time) < timedelta(days=7):
        print("⚠️ 当前月数据不足7天，尝试补充上月数据...")
        last_file = download_month_data(last_year, last_month, save_folder=data_folder)
        df_last = pd.read_csv(last_file)
        df_last = df_last[['SETTLEMENTDATE', 'TOTALDEMAND', 'RRP']]
        df_last['SETTLEMENTDATE'] = pd.to_datetime(df_last['SETTLEMENTDATE'])
        df = pd.concat([df_last, df_current])
    else:
        df = df_current

    df.set_index('SETTLEMENTDATE', inplace=True)
    df = df.resample('1H').mean(numeric_only=True)
    df['DayOfWeek'] = df.index.dayofweek
    df['HourOfDay'] = df.index.hour
    df['IsWeekend'] = df['DayOfWeek'].apply(lambda x: 1 if x >= 5 else 0)
    df['Lag24'] = df['TOTALDEMAND'].shift(24)
    return df

def forecast(df):
    latest_time = df.index.max()
    train_start = latest_time - timedelta(days=7)
    train_end = latest_time
    train_data = df[train_start:train_end].dropna()
    if len(train_data) < 7 * 24:
        raise ValueError("❌ 数据不足7天，无法进行预测。")
    X_train = train_data[['RRP', 'DayOfWeek', 'HourOfDay', 'IsWeekend', 'Lag24']]
    y_train = train_data['TOTALDEMAND']
    predict_start = latest_time + timedelta(hours=1)
    predict_end = predict_start + timedelta(hours=23)
    day_before = predict_start - timedelta(days=1)
    X_predict = df.loc[day_before:day_before + timedelta(hours=23)][['RRP', 'TOTALDEMAND']].copy()
    X_predict.rename(columns={'TOTALDEMAND': 'Lag24'}, inplace=True)
    X_predict['DayOfWeek'] = [predict_start.dayofweek] * 24
    X_predict['HourOfDay'] = list(range(24))
    X_predict['IsWeekend'] = [1 if predict_start.dayofweek >= 5 else 0] * 24
    if len(X_predict) < 24:
        raise ValueError("❌ 无法获取24小时数据用于预测。")
    model = xgb.XGBRegressor(random_state=42)
    model.fit(X_train, y_train)
    y_train_pred = model.predict(X_train)
    rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
    print(f"📉 训练集 RMSE: {rmse:.2f}")
    y_pred = model.predict(X_predict[['RRP', 'DayOfWeek', 'HourOfDay', 'IsWeekend', 'Lag24']])
    predict_df = pd.DataFrame({
        'Time': pd.date_range(start=predict_start, end=predict_end, freq='H'),
        'Predicted_TOTALDEMAND': y_pred
    })
    output_folder = r"D:\Python 脚本\predict_data"
    os.makedirs(output_folder, exist_ok=True)
    output_path = os.path.join(output_folder, f"prediction_{predict_start.date()}.csv")
    predict_df.to_csv(output_path, index=False)
    print(f"✅ 预测完成，结果保存为：{output_path}")
    return predict_df

def evaluate_rmse(df, window_days_list=[7, 14, 30]):
    results = []
    latest_time = df.index.max()
    predict_start = latest_time + timedelta(hours=1)
    day_before = predict_start - timedelta(days=1)
    X_predict = df.loc[day_before:day_before + timedelta(hours=23)][['RRP', 'TOTALDEMAND']].copy()
    X_predict.rename(columns={'TOTALDEMAND': 'Lag24'}, inplace=True)
    X_predict['DayOfWeek'] = [predict_start.dayofweek] * 24
    X_predict['HourOfDay'] = list(range(24))
    X_predict['IsWeekend'] = [1 if predict_start.dayofweek >= 5 else 0] * 24
    if len(X_predict) < 24:
        raise ValueError("❌ 无法获取24小时数据用于预测。")
    for days in window_days_list:
        train_start = latest_time - timedelta(days=days)
        train_end = latest_time
        train_data = df[train_start:train_end].dropna()
        if len(train_data) < days * 24:
            print(f"⚠️ 跳过 {days} 天窗口，数据不足。")
            continue
        X_train = train_data[['RRP', 'DayOfWeek', 'HourOfDay', 'IsWeekend', 'Lag24']]
        y_train = train_data['TOTALDEMAND']
        model = xgb.XGBRegressor(random_state=42)
        model.fit(X_train, y_train)
        y_pred_train = model.predict(X_train)
        train_rmse = np.sqrt(mean_squared_error(y_train, y_pred_train))
        results.append((days, train_rmse))
        print(f"✅ 训练窗口 {days} 天 → 训练 RMSE: {train_rmse:.4f}")
    if results:
        windows, rmses = zip(*results)
        plt.figure(figsize=(8, 5))
        plt.plot(windows, rmses, marker='o')
        plt.title("不同训练窗口的 RMSE 对比（含Lag24）")
        plt.xlabel("训练天数")
        plt.ylabel("训练 RMSE")
        plt.grid(True)
        plt.show()
    else:
        print("⚠️ 无法生成结果图，可能无有效数据。")

if __name__ == "__main__":
    df = prepare_data()
    evaluate_rmse(df)
    forecast(df)
