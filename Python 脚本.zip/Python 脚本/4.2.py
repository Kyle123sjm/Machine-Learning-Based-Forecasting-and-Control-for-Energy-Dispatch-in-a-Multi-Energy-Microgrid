# -*- coding: utf-8 -*-
"""
XGBoost 24h 负荷预测（节假日细分 + 历史/预报天气，按小时）
- 训练：AEMO + 历史（archive）天气（可选：仅回填“历史的最后一天”的缺口，并打标）
- 回测：严格只用真实历史天气，不引入半天或被回填小时
- 预测：用 forecast 天气补齐目标日 24h；Lag24 用前一日真实负荷
- 特征：RRP, DayOfWeek, HourOfDay, IsWeekend, Lag24,
       IsHoliday, IsPublicHoliday, IsSchoolHoliday,
       Temp2m, RH2m, ApparentTemp, CloudCoverTotal, WindSpeed10m
"""

import os, re, glob
import pandas as pd
import numpy as np
import xgboost as xgb
import matplotlib.pyplot as plt
import requests
from datetime import datetime, date, time, timedelta
from typing import List, Tuple, Dict, Union
from sklearn.metrics import mean_squared_error

# ================= 配置区 =================
NORM_METHOD  = "max"
DATA_FOLDER   = r"D:\Python 脚本\aemo_data"
OUTPUT_FOLDER = r"D:\Python 脚本\predict_data"
HOLIDAY_PATH  = r"D:\Python 脚本\holiday"

# —— 仅回填“历史天气的最后一天”的缺失小时（True 开启；False 关闭）
BACKFILL_LAST_WEATHER_DAY_WITH_FORECAST = False  # 建议默认 False

# 天气（阿德莱德）
WEATHER_ARCHIVE_FOLDER  = r"D:\Python 脚本\API"
WEATHER_ARCHIVE_FILE    = os.path.join(WEATHER_ARCHIVE_FOLDER, "openmeteo_archive_20250101_20250818.csv")
WEATHER_ARCHIVE_URL     = (
    "https://archive-api.open-meteo.com/v1/archive"
    "?latitude=-34.9287&longitude=138.5986"
    "&start_date=2025-01-01&end_date=2025-08-18"
    "&hourly=temperature_2m,relative_humidity_2m,apparent_temperature,cloud_cover,wind_speed_10m"
    "&format=csv"
)

WEATHER_FORECAST_FOLDER = r"D:\Python 脚本\API_forecast"
WEATHER_FORECAST_FILE   = os.path.join(WEATHER_FORECAST_FOLDER, "openmeteo_forecast_past1_future1.csv")
WEATHER_FORECAST_URL    = (
    "https://api.open-meteo.com/v1/forecast"
    "?latitude=-34.9214&longitude=138.6075"
    "&hourly=temperature_2m,relative_humidity_2m,apparent_temperature,cloud_cover,wind_speed_10m"
    "&past_days=1&forecast_days=1&format=csv"
)

# 统一天气列名（解析后映射到模型特征名）
WEATHER_COL_MAP = {
    "temperature_2m":       "Temp2m",
    "relative_humidity_2m": "RH2m",
    "apparent_temperature": "ApparentTemp",
    "cloud_cover":          "CloudCoverTotal",
    "cloudcover":           "CloudCoverTotal",
    "wind_speed_10m":       "WindSpeed10m",
    "windspeed_10m":        "WindSpeed10m",
}
WEATHER_FEATURES = ["Temp2m","RH2m","ApparentTemp","CloudCoverTotal","WindSpeed10m"]

# ============== 指标函数 ==============
def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray, method: str = NORM_METHOD):
    rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))
    method = (method or "").lower()
    if method == "max":
        denom = float(np.max(y_true))
    elif method == "mean":
        denom = float(np.mean(y_true))
    elif method == "range":
        denom = float(np.max(y_true) - np.min(y_true))
    else:
        denom = np.nan
    if denom is None or denom <= 0 or np.isnan(denom):
        nrmse = np.nan; nrmse_pct = np.nan
    else:
        nrmse = rmse / denom; nrmse_pct = nrmse * 100.0
    return {"rmse": rmse, "denom": denom, "nrmse": nrmse, "nrmse_percent": nrmse_pct}

# ============== 假期解析（细分 + 按小时） ==============
_HOLIDAY_CACHE: Dict[str, Dict[str, List[Tuple[datetime, datetime]]]] = {}

def _iter_holiday_csvs(path_or_folder: str):
    if os.path.isfile(path_or_folder):
        yield path_or_folder
    elif os.path.isdir(path_or_folder):
        for fp in glob.glob(os.path.join(path_or_folder, "*.csv")):
            yield fp

def _safe_dt(d_str, t_str, is_end=False, all_day=True):
    d = pd.to_datetime(d_str, errors="coerce")
    if pd.isna(d): return None
    d = d.to_pydatetime().date()
    if (t_str is None) or (isinstance(t_str, float) and np.isnan(t_str)) or (str(t_str).strip() == ""):
        if all_day:
            return datetime.combine(d + timedelta(days=1), time(0, 0)) if is_end else datetime.combine(d, time(0, 0))
        else:
            return datetime.combine(d + timedelta(days=1), time(0, 0)) if is_end else datetime.combine(d, time(0, 0))
    else:
        s = str(t_str).strip()
        for fmt in ("%H:%M", "%H:%M:%S"):
            try:
                t = datetime.strptime(s, fmt).time(); break
            except Exception:
                t = None
        if t is None:
            t = time(23, 59, 59) if is_end else time(0, 0)
        return datetime.combine(d, t)

def load_holiday_intervals(path_or_folder: str) -> Dict[str, List[Tuple[datetime, datetime]]]:
    if path_or_folder in _HOLIDAY_CACHE:
        return _HOLIDAY_CACHE[path_or_folder]
    intervals_all: List[Tuple[datetime, datetime]] = []
    intervals_public: List[Tuple[datetime, datetime]] = []
    intervals_school: List[Tuple[datetime, datetime]] = []
    for fp in _iter_holiday_csvs(path_or_folder):
        try: df = pd.read_csv(fp)
        except Exception: df = pd.read_csv(fp, encoding="utf-8-sig")
        cols = {c.lower(): c for c in df.columns}
        start_col = next((cols[k] for k in ["start_datetime","start_dt","start","start date","start_date"] if k in cols), None)
        end_col   = next((cols[k] for k in ["end_datetime","end_dt","end","end date","end_date"] if k in cols), None)
        type_col  = next((cols[k] for k in ["type","category","kind"] if k in cols), None)
        all_day_col = next((cols[k] for k in ["all_day","allday","is_all_day"] if k in cols), None)
        stime_col = next((cols[k] for k in ["start_time","stime","start time"] if k in cols), None)
        etime_col = next((cols[k] for k in ["end_time","etime","end time"] if k in cols), None)
        if start_col is None and "start_date" in cols: start_col = cols["start_date"]
        if end_col   is None and "end_date"   in cols: end_col   = cols["end_date"]
        if start_col is None or end_col is None: continue
        for _, row in df.iterrows():
            all_day = True
            if all_day_col is not None and all_day_col in row:
                try: all_day = bool(row[all_day_col])
                except Exception: all_day = True
            st = _safe_dt(row[start_col], row[stime_col] if (stime_col in df.columns) else None, is_end=False, all_day=all_day)
            ed = _safe_dt(row[end_col],   row[etime_col] if (etime_col in df.columns) else None, is_end=True,  all_day=all_day)
            if st is None or ed is None: continue
            if ed <= st: ed = st + timedelta(hours=1)
            typ = str(row[type_col]).strip().lower() if type_col is not None else ""
            intervals_all.append((st, ed))
            if "school" in typ: intervals_school.append((st, ed))
            elif "public" in typ: intervals_public.append((st, ed))
    result = {"all": intervals_all, "public": intervals_public, "school": intervals_school}
    _HOLIDAY_CACHE[path_or_folder] = result
    return result

def _mark_hours_by_intervals(hourly_index: pd.DatetimeIndex, intervals: List[Tuple[datetime, datetime]]) -> np.ndarray:
    if len(hourly_index) == 0 or len(intervals) == 0:
        return np.zeros(len(hourly_index), dtype=int)
    mark = np.zeros(len(hourly_index), dtype=int)
    for (st, ed) in intervals:
        idx = np.where((hourly_index >= pd.Timestamp(st)) & (hourly_index < pd.Timestamp(ed)))[0]
        if len(idx) > 0: mark[idx] = 1
    return mark

def add_holiday_features(df: pd.DataFrame, holiday_path: str) -> pd.DataFrame:
    intervals = load_holiday_intervals(holiday_path)
    idx = df.index
    public_vec = _mark_hours_by_intervals(idx, intervals["public"])
    school_vec = _mark_hours_by_intervals(idx, intervals["school"])
    all_vec    = np.clip(public_vec + school_vec, 0, 1)
    df["IsPublicHoliday"] = public_vec
    df["IsSchoolHoliday"] = school_vec
    df["IsHoliday"]       = all_vec
    return df

def make_holiday_vectors(start_ts: pd.Timestamp, hours: int, holiday_path: str):
    intervals = load_holiday_intervals(holiday_path)
    times = pd.date_range(start=start_ts, periods=hours, freq="h")
    public_vec = _mark_hours_by_intervals(times, intervals["public"])
    school_vec = _mark_hours_by_intervals(times, intervals["school"])
    all_vec    = np.clip(public_vec + school_vec, 0, 1)
    return all_vec, public_vec, school_vec

# ============== AEMO 下载与准备 ==============
def get_month_url(year, month, region="SA1"):
    ym = f"{year}{month:02d}"
    return f"https://aemo.com.au/aemo/data/nem/priceanddemand/PRICE_AND_DEMAND_{ym}_{region}.csv"

def download_month_data(year, month, region="SA1", save_folder: str = DATA_FOLDER):
    os.makedirs(save_folder, exist_ok=True)
    url = get_month_url(year, month, region)
    filename = url.split("/")[-1]
    save_path = os.path.join(save_folder, filename)
    if os.path.exists(save_path):
        print(f"✅ 已存在：{filename}")
        return save_path
    print(f"⬇️ 正在下载：{filename}")
    try:
        resp = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=60)
        if resp.status_code == 200:
            with open(save_path, "wb") as f: f.write(resp.content)
            print(f"✅ 下载成功：{filename}")
            return save_path
        else:
            print(f"❌ 下载失败：{filename}（HTTP {resp.status_code}）")
            return None
    except Exception as e:
        print(f"❌ 下载异常：{filename}，原因：{e}")
        return None

def clear_data_folder(folder_path: str):
    os.makedirs(folder_path, exist_ok=True)
    for f in glob.glob(os.path.join(folder_path, "*.csv")):
        try:
            os.remove(f); print(f"🗑️ 已删除旧文件：{f}")
        except Exception as e:
            print(f"⚠️ 删除失败 {f}，原因：{e}")

# ============== 天气下载/读取（历史 & 预报） ==============
def _append_tz_param(url: str, tz: str = "Australia/Adelaide") -> str:
    if "timezone=" in url: return url
    sep = "&" if "?" in url else "?"
    return f"{url}{sep}timezone={tz.replace('/', '%2F')}"

def _download_to(path: str, url: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    print(f"⬇️ 下载：{url}")
    r = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=120)
    r.raise_for_status()
    with open(path, "wb") as f: f.write(r.content)
    print(f"✅ 保存：{path}")

def download_archive_weather(force: bool = False) -> str:
    url = _append_tz_param(WEATHER_ARCHIVE_URL)
    if (not force) and os.path.exists(WEATHER_ARCHIVE_FILE):
        print(f"✅ 历史天气已存在：{WEATHER_ARCHIVE_FILE}")
        return WEATHER_ARCHIVE_FILE
    _download_to(WEATHER_ARCHIVE_FILE, url)
    return WEATHER_ARCHIVE_FILE

def download_forecast_weather() -> str:
    url = _append_tz_param(WEATHER_FORECAST_URL)
    _download_to(WEATHER_FORECAST_FILE, url)
    return WEATHER_FORECAST_FILE

def _load_weather_csv(csv_path: str) -> pd.DataFrame:
    """兼容 Open-Meteo 两行表头/一行表头；映射所需列为模型特征名；返回按小时索引的数值型 DataFrame。"""
    df_raw = pd.read_csv(csv_path, dtype=str, keep_default_na=False)
    two_row_header = (
        len(df_raw) >= 2 and
        df_raw.columns[0].strip().lower() in {"latitude", "lat"} and
        str(df_raw.iloc[1, 0]).strip().lower().startswith("time")
    )
    if two_row_header:
        def strip_unit(s: str) -> str:
            return re.sub(r"\s*\(.*?\)\s*$", "", str(s)).strip()
        new_cols = [strip_unit(c) for c in list(df_raw.iloc[1, :])]
        df = df_raw.iloc[2:, :].copy(); df.columns = new_cols
    else:
        df = pd.read_csv(csv_path)

    # 时间列
    time_col = None
    for c in df.columns:
        if str(c).strip().lower().startswith("time"): time_col = c; break
    if time_col is None:
        for cand in ["timestamp", "date", "time (utc)", "time (australia/adelaide)"]:
            if cand in df.columns: time_col = cand; break
    if time_col is None: raise RuntimeError("天气CSV里没有时间列。")

    if time_col != "time": df = df.rename(columns={time_col: "time"})
    df["time"] = pd.to_datetime(df["time"], errors="coerce")
    df = df.dropna(subset=["time"]).set_index("time").sort_index()

    # 字段名标准化
    rename_candidates = {}
    cols_lower = {c.lower(): c for c in df.columns}
    if "cloudcover" in cols_lower and "cloud_cover" not in cols_lower:
        rename_candidates[cols_lower["cloudcover"]] = "cloud_cover"
    if "windspeed_10m" in cols_lower and "wind_speed_10m" not in cols_lower:
        rename_candidates[cols_lower["windspeed_10m"]] = "wind_speed_10m"
    if rename_candidates: df = df.rename(columns=rename_candidates)

    # 只保留需要的列并重命名到特征名
    needed_raw = ["temperature_2m","relative_humidity_2m","apparent_temperature","cloud_cover","wind_speed_10m",
                  "cloudcover","windspeed_10m"]
    existing = [c for c in needed_raw if c in df.columns]
    if not existing: raise RuntimeError("天气CSV中找不到所需小时变量。")
    keep_renamed = {}
    for raw_col in existing:
        std_col = WEATHER_COL_MAP.get(raw_col)
        if std_col is not None: keep_renamed[raw_col] = std_col
    df = df[list(keep_renamed.keys())].rename(columns=keep_renamed)

    # 对齐小时、转数值、适度插值
    df = df.asfreq("h")
    for c in df.columns: df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.interpolate(limit_direction="both").ffill().bfill()
    return df

def backfill_last_day_with_forecast(df_archive: pd.DataFrame) -> pd.DataFrame:
    """仅对历史天气的‘最后一天’进行回填：缺的小时用 forecast 补，真实小时优先；返回带标记列 WeatherIsForecast。"""
    out = df_archive.copy()
    out["WeatherIsForecast"] = 0
    if out.empty: return out
    wx_max = out.index.max()
    if pd.isna(wx_max): return out
    last_day = wx_max.normalize()
    idx_day = pd.date_range(start=last_day, end=last_day + pd.Timedelta(hours=23), freq="h")
    day_arch = out.reindex(idx_day)
    if day_arch[WEATHER_FEATURES].notna().all().all():
        return out  # 已完整，无需回填
    fc_path = download_forecast_weather()
    df_fc = _load_weather_csv(fc_path)
    day_fc = df_fc.reindex(idx_day)
    for col in WEATHER_FEATURES:
        filled = day_arch[col].copy()
        need = filled.isna() & day_fc[col].notna()
        filled[need] = day_fc.loc[need, col]
        out.loc[idx_day, col] = filled.values
        out.loc[idx_day[need], "WeatherIsForecast"] = 1
    return out

# ============== 关键修复：寻找“最后完整 24 小时的 AEMO 日期” ==============
def find_last_full_aemo_day(aemo_hourly: pd.DataFrame) -> pd.Timestamp:
    """
    在小时级 AEMO 数据中，寻找最后一个“TOTALDEMAND 非空小时数 >= 24”的日期。
    返回该日期的 00:00（tz-naive Timestamp）。
    """
    if aemo_hourly.empty or "TOTALDEMAND" not in aemo_hourly.columns:
        raise RuntimeError("AEMO 数据为空或缺少 TOTALDEMAND 列。")

    hours_per_day = (
        aemo_hourly["TOTALDEMAND"]
        .groupby(aemo_hourly.index.normalize())
        .apply(lambda s: int(s.notna().sum()))
        .sort_index()
    )
    full_days = hours_per_day[hours_per_day >= 24]
    if len(full_days) == 0:
        raise RuntimeError("没有找到任何完整 24 小时的 AEMO 天。")

    last_full_day = full_days.index.max()
    tail = hours_per_day.tail(4).to_dict()
    print(f"[AEMO 日覆盖] 最近几天非空小时数: {tail}  |  选用最后完整日: {pd.Timestamp(last_full_day).date()}")
    return pd.Timestamp(last_full_day)

# ============== 组合训练数据（AEMO + 天气） ==============
def prepare_data() -> pd.DataFrame:
    # 1) AEMO（小时聚合 + 找到“最后完整日”）
    clear_data_folder(DATA_FOLDER)
    today = date.today()
    cur_y, cur_m = today.year, today.month
    prev_m = 12 if cur_m == 1 else cur_m - 1
    prev_y = cur_y - 1 if cur_m == 1 else cur_y

    cur_file = download_month_data(cur_y, cur_m, save_folder=DATA_FOLDER)
    if cur_file is None: raise RuntimeError("当月数据下载失败。")

    need_cols = {"SETTLEMENTDATE", "TOTALDEMAND", "RRP"}
    df_cur = pd.read_csv(cur_file, low_memory=False)
    if not need_cols.issubset(df_cur.columns):
        raise RuntimeError("CSV缺少必要列：SETTLEMENTDATE, TOTALDEMAND, RRP")
    df_cur = df_cur[["SETTLEMENTDATE", "TOTALDEMAND", "RRP"]].copy()
    df_cur["SETTLEMENTDATE"] = pd.to_datetime(df_cur["SETTLEMENTDATE"])

    span_hours = (df_cur["SETTLEMENTDATE"].max() - df_cur["SETTLEMENTDATE"].min()).total_seconds() / 3600.0
    need_prev = span_hours < 7*24 or span_hours < 14*24 or span_hours < 30*24

    if need_prev:
        prev_file = download_month_data(prev_y, prev_m, save_folder=DATA_FOLDER)
        if prev_file is not None:
            df_prev = pd.read_csv(prev_file, low_memory=False)
            if need_cols.issubset(df_prev.columns):
                df_prev = df_prev[["SETTLEMENTDATE", "TOTALDEMAND", "RRP"]].copy()
                df_prev["SETTLEMENTDATE"] = pd.to_datetime(df_prev["SETTLEMENTDATE"])
                df_aemo = pd.concat([df_prev, df_cur], ignore_index=True)
            else:
                df_aemo = df_cur
        else:
            df_aemo = df_cur
    else:
        df_aemo = df_cur

    df_aemo = df_aemo.sort_values("SETTLEMENTDATE").set_index("SETTLEMENTDATE")
    df_aemo = df_aemo.resample("h").mean(numeric_only=True)

    # 修复后的锚点：最后完整 24 小时的日期
    last_aemo_full_day = find_last_full_aemo_day(df_aemo)

    # 时间/滞后/节假日
    df_aemo["DayOfWeek"] = df_aemo.index.dayofweek
    df_aemo["HourOfDay"] = df_aemo.index.hour
    df_aemo["IsWeekend"] = (df_aemo["DayOfWeek"] >= 5).astype(int)
    df_aemo["Lag24"] = df_aemo["TOTALDEMAND"].shift(24)
    df_aemo = add_holiday_features(df_aemo, HOLIDAY_PATH)

    # 2) 历史天气
    archive_path = download_archive_weather(force=False)
    df_archive = _load_weather_csv(archive_path)
    if BACKFILL_LAST_WEATHER_DAY_WITH_FORECAST:
        df_archive = backfill_last_day_with_forecast(df_archive)
        if "WeatherIsForecast" not in df_archive.columns:
            df_archive["WeatherIsForecast"] = 0
    else:
        df_archive["WeatherIsForecast"] = 0

    # 3) 合并
    df = df_aemo.join(df_archive, how="left")
    df["WeatherIsForecast"] = df["WeatherIsForecast"].fillna(0).astype(int)

    # 存下预测锚点（列属性）
    df.attrs["last_aemo_full_day"] = last_aemo_full_day

    # 保证关键列存在
    df = df.dropna(subset=["RRP","TOTALDEMAND","Lag24"])
    # 小检查
    chk_day = last_aemo_full_day
    chk = df.loc[chk_day:chk_day + pd.Timedelta(hours=23), ["RRP","TOTALDEMAND"]]
    print(f"[检查] AEMO {chk_day.date()} 覆盖 {len(chk)} 小时, 缺负荷小时={chk['TOTALDEMAND'].isna().sum()}")
    return df

FEATURE_COLS = [
    "RRP","DayOfWeek","HourOfDay","IsWeekend","Lag24",
    "IsHoliday","IsPublicHoliday","IsSchoolHoliday",
    "Temp2m","RH2m","ApparentTemp","CloudCoverTotal","WindSpeed10m"
]

# ============== 训练窗评估（只用真实历史天气） ==============
def evaluate_rmse(df: pd.DataFrame, window_days_list=[7, 14, 30]):
    results = []
    latest_time = df.index.max()
    for days in window_days_list:
        train_start = latest_time - timedelta(days=days)
        train_end   = latest_time
        train_data  = df[train_start:train_end].dropna()
        if "WeatherIsForecast" in train_data.columns:
            train_data = train_data[train_data["WeatherIsForecast"] == 0]
        if len(train_data) < days * 24 * 0.5:
            print(f"⚠️ {days}天窗口有效样本不足，跳过。"); continue

        X_train = train_data[FEATURE_COLS].dropna()
        y_train = train_data.loc[X_train.index, "TOTALDEMAND"]

        model = xgb.XGBRegressor(random_state=42)
        model.fit(X_train, y_train)
        y_pred_train = model.predict(X_train)

        m = compute_metrics(y_train.values, y_pred_train, method=NORM_METHOD)
        results.append((days, m["rmse"], m["nrmse_percent"]))
        print(f"✅ Window {days}d → Train RMSE: {m['rmse']:.4f} | nRMSE({NORM_METHOD})={m['nrmse_percent']:.2f}%")

    if results:
        windows, rmses, nrmse_pcts = zip(*results)
        plt.figure(figsize=(8, 5)); plt.plot(windows, rmses, marker="o")
        plt.title("RMSE Across Training Windows (True Historical Weather Only)")
        plt.xlabel("Training Days"); plt.ylabel("Training RMSE"); plt.grid(True); plt.show()

        os.makedirs(OUTPUT_FOLDER, exist_ok=True)
        pd.DataFrame({
            "train_days": windows,
            "train_RMSE": rmses,
            f"train_nRMSE_{NORM_METHOD}_percent": nrmse_pcts
        }).to_csv(os.path.join(OUTPUT_FOLDER, "train_window_rmse.csv"), index=False)
    else:
        print("⚠️ No results to plot.")

# ============== 一次性未来24h预测（目标日 24h 用 forecast） ==============
def forecast(df: pd.DataFrame, days_ahead: int = 1) -> pd.DataFrame:
    last_aemo_full_day = df.attrs.get("last_aemo_full_day", df.index.max().normalize())
    predict_start = last_aemo_full_day + pd.Timedelta(days=days_ahead)  # 例如 8/19 00:00
    predict_end   = predict_start + pd.Timedelta(hours=23)
    day_before    = predict_start - pd.Timedelta(days=1)

    # 训练集：最近 7 天，仅用真实天气
    train_end   = day_before + pd.Timedelta(hours=23)
    train_start = train_end - pd.Timedelta(days=7)
    train_data  = df[train_start:train_end].dropna()
    if "WeatherIsForecast" in train_data.columns:
        train_data = train_data[train_data["WeatherIsForecast"] == 0]
    if len(train_data) < 7*24*0.7:
        print("⚠️ 训练样本较少，可能影响稳定性。")

    X_train = train_data[FEATURE_COLS].dropna()
    y_train = train_data.loc[X_train.index, "TOTALDEMAND"]

    # -------- 构造前一日基础输入（强制 24 个整点） --------
    full_idx_prev = pd.date_range(start=day_before, periods=24, freq="h")
    aemo_view = df[["RRP","TOTALDEMAND"]].copy()
    base_prev = aemo_view.reindex(full_idx_prev)
    if base_prev["RRP"].isna().any():
        base_prev["RRP"] = base_prev["RRP"].ffill().bfill()
    missing_load_hours = base_prev["TOTALDEMAND"].isna()
    if missing_load_hours.any():
        missing_list = [ts.strftime("%Y-%m-%d %H:%M") for ts in base_prev.index[missing_load_hours]]
        raise ValueError(f"❌ 前一日 TOTALDEMAND 缺少这些小时：{missing_list}。请确认 AEMO 数据是否完整。")

    X_predict = base_prev.rename(columns={"TOTALDEMAND": "Lag24"}).copy()
    X_predict["DayOfWeek"] = [predict_start.dayofweek] * 24
    X_predict["HourOfDay"] = list(range(24))
    X_predict["IsWeekend"] = [1 if predict_start.dayofweek >= 5 else 0] * 24
    iso_all, iso_pub, iso_sch = make_holiday_vectors(predict_start, 24, HOLIDAY_PATH)
    X_predict["IsHoliday"]       = iso_all
    X_predict["IsPublicHoliday"] = iso_pub
    X_predict["IsSchoolHoliday"] = iso_sch
    # ------------------------------------------------------

    # 预报天气（目标日 24h）
    fc_path = download_forecast_weather()
    df_fc = _load_weather_csv(fc_path)
    full_idx = pd.date_range(start=predict_start, end=predict_end, freq="h")
    wx = df_fc.reindex(full_idx).interpolate(limit_direction="both").ffill().bfill()
    if len(wx) < 24:
        raise RuntimeError("❌ 预报天气未覆盖目标日 24 小时。")
    for c in WEATHER_FEATURES:
        X_predict[c] = wx[c].values

    # 训练并预测
    model = xgb.XGBRegressor(random_state=42)
    model.fit(X_train, y_train)
    y_train_pred  = model.predict(X_train)
    train_metrics = compute_metrics(y_train.values, y_train_pred, method=NORM_METHOD)
    print(f"📉 Train RMSE: {train_metrics['rmse']:.4f} | nRMSE({NORM_METHOD})={train_metrics['nrmse_percent']:.2f}%")

    y_pred = model.predict(X_predict[FEATURE_COLS])
    predict_df = pd.DataFrame({
        "Time": full_idx,
        "Predicted_TOTALDEMAND": y_pred
    })
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)
    out_path = os.path.join(OUTPUT_FOLDER, f"prediction_{predict_start.date()}.csv")
    predict_df.to_csv(out_path, index=False)
    print(f"✅ Forecast complete. Results saved to: {out_path}")
    
        # 👉 新增：再保存一个固定文件名，供 Simulink 使用
    latest_path = os.path.join(OUTPUT_FOLDER, "latest_prediction.csv")
    predict_df.to_csv(latest_path, index=False)
    print(f"✅ Latest forecast also saved to: {latest_path}")

    return predict_df

# ============== 逐日回测（严格真值天气，不用半天/补齐小时） ==============
def rolling_to_latest(
    df: pd.DataFrame,
    start_date: Union[pd.Timestamp, None] = None,
    output_folder: str = OUTPUT_FOLDER,
    train_days: int = 7,
    horizon_hours: int = 24
):
    os.makedirs(output_folder, exist_ok=True)
    rmse_list, nrmse_list, all_pred_rows = [], [], []

    latest_time = df.index.max()
    latest_day_with_truth = (latest_time - pd.Timedelta(hours=horizon_hours-1)).normalize()
    if start_date is None:
        start_date = (df.index.min() + pd.Timedelta(days=train_days)).normalize()
    if start_date > latest_day_with_truth:
        print("⚠️ 可评估的最新日期早于起始日期，无法滚动。"); return

    print(f"📆 Rolling from {start_date.date()} to {latest_day_with_truth.date()} (train={train_days}d, horizon={horizon_hours}h)")

    for cur_day in pd.date_range(start=start_date, end=latest_day_with_truth, freq="D"):
        train_end   = cur_day - pd.Timedelta(hours=1)
        train_start = train_end - pd.Timedelta(days=train_days)

        train_data = df[train_start:train_end].dropna()
        if "WeatherIsForecast" in train_data.columns:
            train_data = train_data[train_data["WeatherIsForecast"] == 0]
        if len(train_data) < train_days * 24 * 0.7:
            print(f"⚠️ {cur_day.date()}：训练样本不足，跳过。"); continue

        X_train = train_data[FEATURE_COLS].dropna()
        y_train = train_data.loc[X_train.index, "TOTALDEMAND"]

        predict_start = cur_day
        predict_end   = cur_day + pd.Timedelta(hours=horizon_hours-1)

        day_slice = df.loc[predict_start:predict_end]
        if len(day_slice) < horizon_hours:
            print(f"⚠️ {cur_day.date()}：当日数据不足 {horizon_hours} 小时，跳过。"); continue
        if ("WeatherIsForecast" in day_slice.columns) and (day_slice["WeatherIsForecast"].sum() > 0):
            print(f"⚠️ {cur_day.date()}：当日天气含回填小时，跳过回测。"); continue
        if day_slice[WEATHER_FEATURES].isna().any().any():
            print(f"⚠️ {cur_day.date()}：当日天气特征不完整，跳过。"); continue

        prev_day = df[predict_start - pd.Timedelta(days=1): predict_start - pd.Timedelta(days=1) + pd.Timedelta(hours=horizon_hours-1)]
        if len(prev_day) < horizon_hours:
            print(f"⚠️ {cur_day.date()}：前一日基础输入不足{horizon_hours}小时，跳过。"); continue

        X_predict = prev_day[["RRP","TOTALDEMAND"]].copy()
        X_predict.rename(columns={"TOTALDEMAND":"Lag24"}, inplace=True)
        X_predict["DayOfWeek"] = [predict_start.dayofweek] * horizon_hours
        X_predict["HourOfDay"] = list(range(horizon_hours))
        X_predict["IsWeekend"] = [1 if predict_start.dayofweek >= 5 else 0] * horizon_hours
        iso_all, iso_pub, iso_sch = make_holiday_vectors(predict_start, horizon_hours, HOLIDAY_PATH)
        X_predict["IsHoliday"]       = iso_all
        X_predict["IsPublicHoliday"] = iso_pub
        X_predict["IsSchoolHoliday"] = iso_sch

        for c in WEATHER_FEATURES:
            X_predict[c] = day_slice[c].values

        y_true_series = df[predict_start:predict_end]["TOTALDEMAND"]
        if len(y_true_series) < horizon_hours:
            print(f"⚠️ {cur_day.date()}：真实值不足{horizon_hours}小时，跳过。"); continue
        y_true = y_true_series.values

        model = xgb.XGBRegressor(random_state=42)
        model.fit(X_train, y_train)
        y_pred = model.predict(X_predict[FEATURE_COLS])

        m = compute_metrics(y_true, y_pred, method=NORM_METHOD)
        rmse_list.append((cur_day.date(), float(m["rmse"])))
        nrmse_list.append((cur_day.date(), float(m["nrmse_percent"]) if not np.isnan(m["nrmse_percent"]) else np.nan))
        print(f"✅ {cur_day.date()} RMSE: {m['rmse']:.4f} | nRMSE({NORM_METHOD})={m['nrmse_percent']:.2f}%")

        time_index = pd.date_range(start=predict_start, end=predict_end, freq="h")
        all_pred_rows.append(pd.DataFrame({
            "Date": [cur_day.date()] * horizon_hours,
            "Time": time_index,
            "Actual_TOTALDEMAND": y_true,
            "Pred_TOTALDEMAND": y_pred
        }))

        plt.figure(figsize=(10, 5))
        plt.plot(range(horizon_hours), y_true, label="Actual")
        plt.plot(range(horizon_hours), y_pred, label="Predicted")
        plt.title(f"Forecast vs Actual for {cur_day.date()}")
        plt.xlabel("Hour"); plt.ylabel("TOTALDEMAND"); plt.legend()
        plt.tight_layout(); plt.savefig(os.path.join(output_folder, f"forecast_{cur_day.date()}.png")); plt.close()

    if all_pred_rows:
        all_preds = pd.concat(all_pred_rows, ignore_index=True)
        all_preds.to_csv(os.path.join(output_folder, "rolling_predictions_all.csv"), index=False)

        dates_r, rmses = zip(*rmse_list)
        dates_n, nrmse_pcts = zip(*nrmse_list)

        plt.figure(figsize=(10, 5))
        plt.plot(dates_r, rmses, marker='o', linestyle='-')
        plt.title("Daily Forecast RMSE (True Weather Only)")
        plt.xlabel("Date"); plt.ylabel("RMSE"); plt.grid(True)
        plt.tight_layout(); plt.savefig(os.path.join(output_folder, "daily_rmse_curve.png")); plt.show()

        pd.DataFrame({
            "Date": dates_r,
            "RMSE": rmses,
            f"nRMSE_{NORM_METHOD}_percent": nrmse_pcts
        }).to_csv(os.path.join(output_folder, "rolling_metrics.csv"), index=False)
    else:
        print("⚠️ 无有效滚动结果（可能因为当日天气非真值而被跳过）。")

# ============== 主程序 ==============
if __name__ == "__main__":
    df = prepare_data()
    evaluate_rmse(df, window_days_list=[7, 14, 30])  # 可选
    rolling_to_latest(df)                             # 核心回测
    forecast(df, days_ahead=1)                        # 预测下一整天（如 8/19）
