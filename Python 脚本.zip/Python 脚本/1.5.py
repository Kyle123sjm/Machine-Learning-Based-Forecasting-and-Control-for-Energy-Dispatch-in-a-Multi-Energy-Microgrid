import pandas as pd
import numpy as np
import xgboost as xgb
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error, mean_squared_error
import os
import glob

# 1. 读取最新下载的CSV文件
data_folder = r"D:\Python 脚本\aemo_data"
csv_files = glob.glob(os.path.join(data_folder, "*.csv"))
if not csv_files:
    raise FileNotFoundError("未找到任何CSV文件，请先下载最新数据")

csv_path = csv_files[0]
df = pd.read_csv(csv_path)

# 2. 数据清洗与格式处理
df = df[['SETTLEMENTDATE', 'TOTALDEMAND', 'RRP']].copy()
df['SETTLEMENTDATE'] = pd.to_datetime(df['SETTLEMENTDATE'])
df[['TOTALDEMAND', 'RRP']] = df[['TOTALDEMAND', 'RRP']].apply(pd.to_numeric, errors='coerce')
df.dropna(inplace=True)
df.set_index('SETTLEMENTDATE', inplace=True)
df = df.resample('1H').mean()

# 3. 设置滚动窗口预测
window_days = 7
mae_list, rmse_list, date_list = [], [], []
prediction_list, actual_list = [], []

start_date = df.index.min() + pd.Timedelta(days=window_days)
end_date = df.index.max() - pd.Timedelta(days=1)

while start_date <= end_date:
    train_start = start_date - pd.Timedelta(days=window_days)
    train_end = start_date - pd.Timedelta(hours=1)

    train_data = df[train_start:train_end]
    test_data = df[start_date:start_date + pd.Timedelta(hours=23)]

    if len(train_data) < 24 * window_days or len(test_data) < 24:
        start_date += pd.Timedelta(days=1)
        continue

    X_train = train_data[['RRP']]
    y_train = train_data['TOTALDEMAND']
    X_test = test_data[['RRP']]
    y_true = test_data['TOTALDEMAND']

    model = xgb.XGBRegressor()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    # 保存误差与预测结果
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    date_list.append(start_date.strftime("%Y-%m-%d"))
    mae_list.append(mae)
    rmse_list.append(rmse)
    prediction_list.append(pd.Series(y_pred, index=y_true.index))
    actual_list.append(y_true)

    start_date += pd.Timedelta(days=1)

# 4. 绘制误差趋势图
plt.figure(figsize=(10, 5))
plt.plot(date_list, mae_list, marker='o', label='MAE')
plt.plot(date_list, rmse_list, marker='x', label='RMSE')
plt.title("Rolling Forecast Error (7-Day Window)")
plt.xlabel("Forecast Date")
plt.ylabel("Error (kW)")
plt.xticks(rotation=45)
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# 5. 每天生成一张预测 vs 实际的对比图
for i, date in enumerate(date_list):
    plt.figure(figsize=(10, 4))
    plt.plot(actual_list[i].index, actual_list[i].values, label="Actual", linewidth=2)
    plt.plot(actual_list[i].index, prediction_list[i].values, label="Predicted", linestyle="--")
    plt.title(f"Prediction vs Actual on {date}")
    plt.xlabel("Time")
    plt.ylabel("TOTALDEMAND (kW)")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.xticks(rotation=45)
    plt.show()
