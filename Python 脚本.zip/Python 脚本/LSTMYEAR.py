import pandas as pd
import numpy as np
import os, glob
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense

# ========= 1. 数据读取（2024 + 2025年） ========= #
data_folder = r"D:\Python 脚本\aemo_data"
all_files = sorted(glob.glob(os.path.join(data_folder, "*.csv")))

df_list = []
for file in all_files:
    df = pd.read_csv(file)
    df['SETTLEMENTDATE'] = pd.to_datetime(df['SETTLEMENTDATE'])
    df = df[['SETTLEMENTDATE', 'TOTALDEMAND', 'RRP']]
    df_list.append(df)

df = pd.concat(df_list, ignore_index=True)
df.set_index('SETTLEMENTDATE', inplace=True)

# ========= 2. 只保留到 2025-08-07 的数据 ========= #
df = df.resample('1H').mean(numeric_only=True)
df = df[df.index >= '2024-01-01']
df['DayOfWeek'] = df.index.dayofweek
df['HourOfDay'] = df.index.hour
df['IsWeekend'] = df['DayOfWeek'].apply(lambda x: 1 if x >= 5 else 0)
df['Lag24'] = df['TOTALDEMAND'].shift(24)
df.dropna(inplace=True)

# ========= 3. 分离训练数据与预测目标 ========= #
train_df = df[df.index < '2025-08-07 00:00:00']
predict_df = df[(df.index >= '2025-08-07 00:00:00') & (df.index < '2025-08-08 00:00:00')]
y_true = predict_df['TOTALDEMAND'].values  # 实际值

# ========= 4. 构造滑动窗口训练数据 ========= #
features = ['RRP', 'DayOfWeek', 'HourOfDay', 'IsWeekend', 'Lag24']
target = 'TOTALDEMAND'

scaler_x = MinMaxScaler()
scaler_y = MinMaxScaler()

X_scaled = scaler_x.fit_transform(train_df[features])
y_scaled = scaler_y.fit_transform(train_df[[target]])

scaled_df = pd.DataFrame(X_scaled, columns=features, index=train_df.index)
scaled_df['TOTALDEMAND'] = y_scaled

def create_sequences(df, seq_len=24):
    X, y = [], []
    for i in range(seq_len, len(df)):
        X.append(df[features].iloc[i - seq_len:i].values)
        y.append(df['TOTALDEMAND'].iloc[i])
    return np.array(X), np.array(y)

X_train, y_train = create_sequences(scaled_df)

# ========= 5. 构造预测用输入序列（8月6日24小时） ========= #
X_pred_input = df.loc["2025-08-06 00:00:00":"2025-08-06 23:00:00"][features]
X_pred_scaled = scaler_x.transform(X_pred_input)
X_pred = X_pred_scaled.reshape(1, 24, len(features))  # 单个样本输入

# ========= 6. 构建 LSTM 模型并训练 ========= #
model = Sequential()
model.add(LSTM(64, input_shape=(24, len(features))))
model.add(Dense(1))  # 输出一个小时的 TOTALDEMAND
model.compile(optimizer='adam', loss='mse')
model.fit(X_train, y_train, epochs=30, batch_size=32, verbose=1)

# ========= 7. 滚动预测未来 24 小时 ========= #
y_preds = []
current_input = X_pred.copy()
for i in range(24):
    y_next = model.predict(current_input)[0, 0]
    y_preds.append(y_next)
    
    # 构造下一个小时的输入（滑动窗口 + 预测值替换 Lag24）
    next_hour_index = pd.Timestamp("2025-08-07 00:00:00") + pd.Timedelta(hours=i)
    next_row = df.loc[next_hour_index][['RRP', 'DayOfWeek', 'HourOfDay', 'IsWeekend']].values.tolist()
    next_lag24 = scaler_y.transform([[y_next]])[0][0]  # 预测值作为 Lag24
    next_features = next_row + [next_lag24]
    
    current_input = np.append(current_input[:, 1:, :], [[next_features]], axis=1)

# ========= 8. 反归一化 & 评估 ========= #
y_pred_final = scaler_y.inverse_transform(np.array(y_preds).reshape(-1, 1)).flatten()

rmse = np.sqrt(mean_squared_error(y_true, y_pred_final))
print(f"\n📅 LSTM预测范围：2025-08-07")
print(f"📉 LSTM RMSE（全历史训练）：{rmse:.4f}")

# ========= 9. 可视化 ========= #
plt.figure(figsize=(10, 5))
plt.plot(y_true, label='Actual (2025-08-07)')
plt.plot(y_pred_final, label='LSTM Prediction')
plt.title('LSTM Forecast vs Actual (2025-08-07)')
plt.xlabel('Hour')
plt.ylabel('TOTALDEMAND')
plt.legend()
plt.grid(True)
plt.show()
