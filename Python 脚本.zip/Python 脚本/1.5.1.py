import pandas as pd
import numpy as np
import xgboost as xgb
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error, mean_squared_error
import os
import glob

# ========== 1. 合并所有CSV文件 ==========
data_folder = r"D:\Python 脚本\aemo_data"
csv_files = glob.glob(os.path.join(data_folder, "*.csv"))
if not csv_files:
    raise FileNotFoundError("未找到任何CSV文件，请先下载最新数据")

dfs = []
for file in csv_files:
    df_temp = pd.read_csv(file, usecols=['SETTLEMENTDATE', 'TOTALDEMAND', 'RRP'])
    df_temp['SETTLEMENTDATE'] = pd.to_datetime(df_temp['SETTLEMENTDATE'])
    df_temp[['TOTALDEMAND', 'RRP']] = df_temp[['TOTALDEMAND', 'RRP']].apply(pd.to_numeric, errors='coerce')
    df_temp.dropna(inplace=True)
    dfs.append(df_temp)

df = pd.concat(dfs)
df.set_index('SETTLEMENTDATE', inplace=True)
df = df.resample('1H').mean()

# ========== 2. 设置滚动预测目标日期：2025-08-07 ==========
window_days = 7
target_date = pd.to_datetime("2025-08-07")

train_start = target_date - pd.Timedelta(days=window_days)
train_end = target_date - pd.Timedelta(hours=1)
test_end = target_date + pd.Timedelta(hours=23)

train_data = df[train_start:train_end]
test_data = df[target_date:test_end]

if len(train_data) < 24 * window_days or len(test_data) < 24:
    raise ValueError("❌ 数据不足，无法进行预测，请确保包含7月和8月数据")

# ========== 3. 建模训练并预测 ==========
X_train = train_data[['RRP']]
y_train = train_data['TOTALDEMAND']
X_test = test_data[['RRP']]
y_true = test_data['TOTALDEMAND']

model = xgb.XGBRegressor()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

mae = mean_absolute_error(y_true, y_pred)
rmse = np.sqrt(mean_squared_error(y_true, y_pred))
print(f"📊 预测日期：{target_date.date()} | MAE = {mae:.2f} | RMSE = {rmse:.2f}")

# ========== 4. 绘制对比图 ==========
plt.figure(figsize=(10, 4))
plt.plot(y_true.index, y_true.values, label="Actual", linewidth=2)
plt.plot(y_true.index, y_pred, label="Predicted", linestyle="--")
plt.title(f"Prediction vs Actual on {target_date.date()} (7-Day Training)")
plt.xlabel("Hour")
plt.ylabel("TOTALDEMAND (kW)")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.xticks(rotation=45)
plt.show()
