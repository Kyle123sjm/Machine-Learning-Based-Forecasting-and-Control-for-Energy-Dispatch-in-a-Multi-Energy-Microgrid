import pandas as pd
import numpy as np
import xgboost as xgb
import matplotlib.pyplot as plt
import os
import requests
import datetime
import glob
from datetime import timedelta, date

# ========== 全局路径 ========== #
download_folder = r"D:\Python 脚本\aemo_data"
output_folder = r"D:\Python 脚本\predict_data"
os.makedirs(download_folder, exist_ok=True)
os.makedirs(output_folder, exist_ok=True)

# ========== 1. 构造月份URL函数 ========== #
def get_month_url(year, month, region="SA1"):
    ym = f"{year}{month:02d}"
    return f"https://aemo.com.au/aemo/data/nem/priceanddemand/PRICE_AND_DEMAND_{ym}_{region}.csv"

# ========== 2. 清空旧数据 ========== #
def clear_old_files(folder):
    old_files = glob.glob(os.path.join(folder, "*.csv"))
    for f in old_files:
        try:
            os.remove(f)
            print(f"🗑️ 已删除旧文件：{f}")
        except Exception as e:
            print(f"⚠️ 删除失败：{f}，原因：{e}")

# ========== 3. 下载指定年月数据 ========== #
def download_month_data(year, month, region="SA1", save_folder=download_folder):
    url = get_month_url(year, month, region)
    filename = url.split("/")[-1]
    save_path = os.path.join(save_folder, filename)

    if os.path.exists(save_path):
        print(f"📁 文件已存在：{save_path}")
        return save_path

    print(f"🌐 开始下载：{url}")
    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        with open(save_path, "wb") as f:
            f.write(response.content)
        print(f"✅ 下载成功，文件已保存：{save_path}")
        return save_path
    else:
        print(f"❌ 下载失败，状态码：{response.status_code}")
        return None

# ========== 4. 准备数据 ========== #
def prepare_data():
    clear_old_files(download_folder)

    today = date.today()
    current_year, current_month = today.year, today.month
    last_year, last_month = (current_year - 1, 12) if current_month == 1 else (current_year, current_month - 1)

    # 下载当前月数据
    current_file = download_month_data(current_year, current_month)
    if not current_file:
        raise ValueError("❌ 当前月份数据下载失败")

    df_current = pd.read_csv(current_file)[['SETTLEMENTDATE', 'TOTALDEMAND', 'RRP']]
    df_current['SETTLEMENTDATE'] = pd.to_datetime(df_current['SETTLEMENTDATE'])

    # 是否足够7天
    latest_time = df_current['SETTLEMENTDATE'].max()
    earliest_time = latest_time - timedelta(days=7)
    if df_current['SETTLEMENTDATE'].min() > earliest_time:
        print("⚠️ 当前数据不足7天，尝试补充上月数据...")

        last_file = download_month_data(last_year, last_month)
        if not last_file:
            raise ValueError("❌ 上月数据下载失败")

        df_last = pd.read_csv(last_file)[['SETTLEMENTDATE', 'TOTALDEMAND', 'RRP']]
        df_last['SETTLEMENTDATE'] = pd.to_datetime(df_last['SETTLEMENTDATE'])

        df_all = pd.concat([df_last, df_current])
    else:
        df_all = df_current

    # 统一时间格式、按小时重采样
    df_all.set_index('SETTLEMENTDATE', inplace=True)
    df_all = df_all.resample('1H').mean(numeric_only=True)

    # 再次确认是否有足够数据
    if len(df_all.dropna()) < 7 * 24:
        raise ValueError("❌ 补足后数据仍不足7天")

    return df_all

# ========== 5. 训练与预测 ========== #
def forecast(df):
    latest_time = df.index.max()
    train_data = df[latest_time - timedelta(days=7): latest_time]

    X_train = train_data[['RRP']]
    y_train = train_data['TOTALDEMAND']

    # 预测未来24小时
    predict_start = latest_time + timedelta(hours=1)
    predict_end = predict_start + timedelta(hours=23)
    X_predict = df.loc[predict_start - timedelta(days=1):predict_start - timedelta(days=1) + timedelta(hours=23)][['RRP']]

    if len(X_predict) < 24:
        raise ValueError("❌ 无法获取24小时的RRP数据用于预测。")

    model = xgb.XGBRegressor()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_predict)

    predict_df = pd.DataFrame({
        'Time': pd.date_range(start=predict_start, end=predict_end, freq='H'),
        'Predicted_TOTALDEMAND': y_pred
    })

    output_path = os.path.join(output_folder, f"prediction_{predict_start.date()}.csv")
    predict_df.to_csv(output_path, index=False)
    print(f"✅ 预测完成，结果保存为：{output_path}")
    return predict_df

# ========== 6. 主函数 ========== #
if __name__ == "__main__":
    df = prepare_data()
    forecast(df)
