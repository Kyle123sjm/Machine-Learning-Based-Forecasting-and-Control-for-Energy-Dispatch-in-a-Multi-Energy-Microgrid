from net_env import NetEnvironment
from net_agent import NetAgent
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False


def policy_train(env, agent, episode_num):
    reward_sum_line = []
    running_reward = 0
    flag = True
    P_MT_action_list = []
    P_g_action_list = []
    P_B_action_list = []
    H_D_state_list = []
    for i in range(episode_num):
        observation = env.reset(np.random.uniform(0.2, 0.9))
        reward_episode = []
        while True:
            action = agent.choose_action(np.array(observation))
            observation_, reward, done = env.step(action)
            agent.store_transition(observation, action, reward, observation_)
            reward_episode.append(reward)
            observation = observation_
            if i == episode_num - 1:
                a = env.action_space[action]
                P_MT_action_list.append(env.P_MT_action[a[0]])
                P_g_action_list.append(env.P_g_action[a[1]])
                P_B_action_list.append(env.P_B_action[a[2]])
                H_D_state_list.append(observation[6])

            if done:
                if flag:
                    running_reward = sum(reward_episode)
                    flag = False
                else:
                    running_reward = running_reward * 0.95 + sum(reward_episode) * 0.05
                reward_sum_line.append(running_reward)
                print("episode:", i + 1, "  reward:", running_reward)
                agent.learn()
                break

    # ====== 原有图 ======
    reward_pd = pd.Series(reward_sum_line)
    reward_pd.to_csv('reward/reward_no_policy.csv')
    agent.save_model()

    plt.figure("奖励")
    plt.xlabel('episode'); plt.ylabel('reward')
    plt.plot(reward_sum_line, '-')

    plt.figure("联合发电单元功率")
    plt.xlabel('time'); plt.ylabel('功率')
    plt.plot(P_MT_action_list, '-')

    plt.figure("电网流入微能源网的电功率")
    plt.xlabel('time'); plt.ylabel('功率')
    plt.plot(P_g_action_list, '-')

    plt.figure("蓄电池充放电功率")
    plt.xlabel('time'); plt.ylabel('功率')
    plt.plot(P_B_action_list, '-')

    plt.figure("蓄电池荷电状态")
    plt.xlabel('time'); plt.ylabel('荷电状态')
    plt.plot(H_D_state_list, '-')

    # ====== 新增：电力侧供需平衡图（最后一回合）======
    # 供给 = MT + Grid(购电) + Battery放电 + PV + WT
    # 需求 = 电负荷 + Battery充电 + 电制冷(L_c / η_EC)
    try:
        eta_EC = getattr(env, 'eta_EC', 4.0)
        n = min(len(P_MT_action_list), len(P_g_action_list), len(P_B_action_list),
                len(env.P_PV), len(env.P_WT), len(env.L_e), len(env.L_c))
        # 电池充/放
        P_BD = [max(0.0, x) for x in P_B_action_list[:n]]      # 放电
        P_BC = [max(0.0, -x) for x in P_B_action_list[:n]]     # 充电
        # 供给与需求
        supply = [P_MT_action_list[k] + P_g_action_list[k] + P_BD[k] + env.P_PV[k] + env.P_WT[k]
                  for k in range(n)]
        demand = [env.L_e[k] + P_BC[k] + (env.L_c[k] / eta_EC) for k in range(n)]
        imbalance = [supply[k] - demand[k] for k in range(n)]

        plt.figure("电力侧供需平衡（最后一回合）")
        plt.xlabel('time (hour)'); plt.ylabel('功率 (kW)')
        plt.plot(range(n), supply, label='供给')
        plt.plot(range(n), demand, label='需求')
        plt.plot(range(n), imbalance, '--', label='供需差')
        plt.legend()
    except Exception as e:
        print("供需平衡图绘制跳过：", e)

    plt.tight_layout()
    plt.show()



max_episode = 60000

phi = np.random.uniform(0.2, 0.9)
net_env = NetEnvironment(phi)
net_agent = NetAgent(len(net_env.action_space), 7)

policy_train(net_env, net_agent, max_episode)
